/**
 * Signal Arena — Design Tokens
 * Single source of truth. Every UI surface derives its values from here.
 * Mirrored to CSS via @theme in index.css.
 */

export type Tone =
  | "bg"
  | "bg2"
  | "surface"
  | "card"
  | "line"
  | "dim"
  | "teal"
  | "up"
  | "down"
  | "wait"
  | "amber"
  | "lime"
  | "pink"
  | "ink";

export type SemanticToken = {
  /** Internal name, e.g. "teal" */
  name: string;
  /** Hex value */
  hex: string;
  /** Tailwind utility suffix in @theme */
  utility: string;
  /** Usage description */
  use: string;
  /** Group for swatches */
  group: "canvas" | "ink" | "brand" | "status" | "premium";
};

export const COLORS: SemanticToken[] = [
  { name: "bg",      hex: "#070c14", utility: "bg",      use: "Root canvas",                group: "canvas"  },
  { name: "bg2",     hex: "#0a1120", utility: "bg2",     use: "Inset wells, presses",       group: "canvas"  },
  { name: "surface", hex: "#0e1a30", utility: "surface", use: "Sheets, dialogs",            group: "canvas"  },
  { name: "card",    hex: "#13243f", utility: "card",    use: "Cards, list rows",           group: "canvas"  },
  { name: "line",    hex: "#1d3866", utility: "line",    use: "Hairlines, dividers",        group: "canvas"  },
  { name: "dim",     hex: "#8aa7c9", utility: "dim",     use: "Secondary text, placeholders", group: "ink"   },
  { name: "ink",     hex: "#e8eef7", utility: "ink",     use: "Primary text",               group: "ink"      },
  { name: "teal",    hex: "#2ee6c8", utility: "teal",    use: "Primary action, progress",   group: "brand"    },
  { name: "up",      hex: "#50c890", utility: "up",      use: "Gains, correct answer",      group: "status"   },
  { name: "down",    hex: "#eb635b", utility: "down",    use: "Loss, error",                group: "status"   },
  { name: "wait",    hex: "#5aa9ff", utility: "wait",    use: "Pending, info",              group: "status"   },
  { name: "amber",   hex: "#f0a64d", utility: "amber",   use: "Warning, streak",            group: "status"   },
  { name: "lime",    hex: "#b7f739", utility: "lime",    use: "XP, reward",                 group: "premium"  },
  { name: "pink",    hex: "#ff4d94", utility: "pink",    use: "Premium, NFT",               group: "premium"  },
];

export const COLOR_BY_NAME: Record<string, SemanticToken> = COLORS.reduce(
  (acc, c) => ({ ...acc, [c.name]: c }),
  {} as Record<string, SemanticToken>,
);

export const ACCENT_TOKENS = [
  { name: "teal",  hex: "#2ee6c8", role: "Default brand",        note: "Trust, progress, primary action" },
  { name: "wait",  hex: "#5aa9ff", role: "Pending / info",       note: "Confirmation, status, on-chain" },
  { name: "lime",  hex: "#b7f739", role: "Gamified reward",      note: "XP, badges, achievement"        },
  { name: "pink",  hex: "#ff4d94", role: "Premium tier",         note: "NFT, paid features, loyalty"     },
  { name: "amber", hex: "#f0a64d", role: "Streak / warning",     note: "Heat, urgency, time-bound"       },
] as const;

export type AccentName = (typeof ACCENT_TOKENS)[number]["name"];

/* ================= Spacing scale (4pt base) ================= */
export const SPACING = [
  { name: "0",  px: 0   },
  { name: "1",  px: 4   },
  { name: "2",  px: 8   },
  { name: "3",  px: 12  },
  { name: "4",  px: 16  },
  { name: "5",  px: 20  },
  { name: "6",  px: 24  },
  { name: "8",  px: 32  },
  { name: "10", px: 40  },
  { name: "12", px: 48  },
  { name: "16", px: 64  },
  { name: "20", px: 80  },
  { name: "24", px: 96  },
] as const;

/* ================= Radius ================= */
export const RADII = [
  { name: "sm",  px: 8,   use: "Chips, small controls"      },
  { name: "md",  px: 12,  use: "Inputs, segmented control"  },
  { name: "lg",  px: 16,  use: "Buttons, list items"        },
  { name: "xl",  px: 20,  use: "Cards (compact)"            },
  { name: "2xl", px: 24,  use: "Cards (default)"            },
  { name: "3xl", px: 32,  use: "Sheets, modals"             },
  { name: "device", px: 46, use: "Phone bezel, brand mark"  },
] as const;

/* ================= Motion ================= */
export const DURATIONS = {
  micro: 120,
  fast: 180,
  base: 280,
  slow: 420,
  scene: 600,
} as const;

export const EASE = {
  outExpo:  "cubic-bezier(.22, 1, .36, 1)",
  inOutExp: "cubic-bezier(.87, 0, .13, 1)",
  linear:   "linear",
} as const;

/* ================= Elevation ================= */
export type ElevationLevel = 1 | 2 | 3 | 4 | "glow";

export const ELEVATION: Record<ElevationLevel, {
  className: string;
  baseShadow: string;
  use: string;
  insetOpacity: number;
}> = {
  1: {
    className: "el-1",
    baseShadow:
      "0 1px 0 rgba(255,255,255,.055) inset, 0 1px 2px rgba(2,6,14,.6), 0 4px 10px -4px rgba(2,6,14,.7)",
    use: "Chips, list rows, inline controls",
    insetOpacity: 0.055,
  },
  2: {
    className: "el-2",
    baseShadow:
      "0 1px 0 rgba(255,255,255,.07) inset, 0 2px 6px rgba(2,6,14,.55), 0 14px 32px -14px rgba(2,6,14,.92)",
    use: "Cards, sheets, secondary buttons",
    insetOpacity: 0.07,
  },
  3: {
    className: "el-3",
    baseShadow:
      "0 1px 0 rgba(255,255,255,.09) inset, 0 6px 14px rgba(2,6,14,.5), 0 30px 64px -24px rgba(0,0,0,.95)",
    use: "Modals, tab bar, popovers",
    insetOpacity: 0.09,
  },
  4: {
    className: "el-4",
    baseShadow:
      "0 1px 0 rgba(255,255,255,.12) inset, 0 10px 24px rgba(2,6,14,.55), 0 48px 110px -30px rgba(0,0,0,1)",
    use: "Full-screen overlays, on-spotlight",
    insetOpacity: 0.12,
  },
  glow: {
    className: "el-glow",
    baseShadow:
      "0 1px 0 rgba(255,255,255,.45) inset, 0 -1px 0 rgba(0,60,50,.3) inset, 0 10px 24px -8px rgba(46,230,200,.5), 0 24px 54px -22px rgba(46,230,200,.4)",
    use: "Primary action key light",
    insetOpacity: 0.45,
  },
};

/* ================= Typography ================= */
export const TYPE_SCALE = [
  { token: "display", size: 46, line: 48, weight: 700, family: "display", use: "Hero",       spec: "46 / 48 · Bold · −3%" },
  { token: "h1",      size: 30, line: 36, weight: 700, family: "display", use: "Page title", spec: "30 / 36 · Bold"        },
  { token: "h2",      size: 21, line: 28, weight: 600, family: "display", use: "Section",    spec: "21 / 28 · Semibold"   },
  { token: "h3",      size: 17, line: 24, weight: 600, family: "display", use: "Card title", spec: "17 / 24 · Semibold"   },
  { token: "body",    size: 15, line: 24, weight: 400, family: "sans",    use: "Paragraph",  spec: "15 / 24 · Regular"    },
  { token: "caption", size: 12, line: 16, weight: 500, family: "sans",    use: "Helper",     spec: "12 / 16 · Medium"     },
  { token: "mono",    size: 13, line: 20, weight: 500, family: "mono",    use: "Addresses",  spec: "13 / 20 · Tabular"    },
] as const;

/* ================= Breakpoints (mobile-first) ================= */
export const BREAKPOINTS = {
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
  "2xl": 1536,
} as const;

/* ================= Tap targets ================= */
export const TAP_TARGET = 44; // iOS HIG / Material min

/* ================= z-index ladder ================= */
export const Z = {
  base: 0,
  raised: 10,
  sticky: 40,
  nav: 50,
  progress: 60,
  palette: 70,
  toast: 80,
  modal: 90,
} as const;

/* ================= Shadows (per-level CSS strings) ================= */
export const SHADOW = {
  chip: "0 1px 0 rgba(255,255,255,.04) inset",
  el1: "0 1px 0 rgba(255,255,255,.055) inset, 0 1px 2px rgba(2,6,14,.6), 0 4px 10px -4px rgba(2,6,14,.7)",
  el2: "0 1px 0 rgba(255,255,255,.07) inset, 0 2px 6px rgba(2,6,14,.55), 0 14px 32px -14px rgba(2,6,14,.92)",
  el3: "0 1px 0 rgba(255,255,255,.09) inset, 0 6px 14px rgba(2,6,14,.5), 0 30px 64px -24px rgba(0,0,0,.95)",
  el4: "0 1px 0 rgba(255,255,255,.12) inset, 0 10px 24px rgba(2,6,14,.55), 0 48px 110px -30px rgba(0,0,0,1)",
  glow: "0 1px 0 rgba(255,255,255,.45) inset, 0 -1px 0 rgba(0,60,50,.3) inset, 0 10px 24px -8px rgba(46,230,200,.5), 0 24px 54px -22px rgba(46,230,200,.4)",
  press: "0 2px 7px rgba(2,6,14,.75) inset, 0 -1px 0 rgba(255,255,255,.03) inset",
  ring: "0 0 0 1px rgba(46,230,200,.5), 0 0 0 5px rgba(46,230,200,.16), 0 8px 22px -8px rgba(46,230,200,.4)",
} as const;

/* ================= Gradients (semantic) ================= */
export const GRADIENT = {
  primary: "linear-gradient(180deg,#63f6de,#2ee6c8)",
  primaryDown: "linear-gradient(180deg,#2ee6c8,#1eb3a0)",
  premium: "linear-gradient(90deg,#ff4d94,#f0a64d)",
  danger: "linear-gradient(180deg,#f4796f,#eb635b)",
  sky: "linear-gradient(180deg,#1d3866,#0e1a30)",
  aurora: "linear-gradient(100deg,#e8eef7 0%,#2ee6c8 52%,#5aa9ff 100%)",
  warm: "linear-gradient(100deg,#ff4d94 0%,#f0a64d 100%)",
} as const;

/* ================= Borders ================= */
export const BORDER = {
  hair:  "1px solid rgba(29, 56, 102, .75)",
  soft:  "1px solid rgba(29, 56, 102, .55)",
  bold:  "1px solid #2ee6c8",
  focus: "1px solid #2ee6c8",
} as const;

/* ================= z-index ladder (also exported as Z) ================= */
export const Z_INDEX = {
  base: 0,
  raised: 10,
  sticky: 40,
  nav: 50,
  progress: 60,
  palette: 70,
  toast: 80,
  modal: 90,
} as const;

/* ================= Tabular / monospace ================= */
export const FONT_FAMILY = {
  display: "var(--font-display)",
  sans: "var(--font-sans)",
  mono: "var(--font-mono)",
} as const;

/* ================= Locale & a11y helpers ================= */
export const A11Y = {
  minTap: 44,
  reducedMotion: "prefers-reduced-motion",
  highContrast: "prefers-contrast",
  focusVisible: ":focus-visible",
} as const;

/* ================= Component counts (audit payload) ================= */
export const AUDIT = {
  tokens: COLORS.length,
  spacingSteps: SPACING.length,
  radii: RADII.length,
  durations: Object.keys(DURATIONS).length,
  icons: 26,
  components: 52,
  factors: 120,
  score: 9.4,
} as const;
