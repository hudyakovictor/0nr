import { useEffect, useState } from "react";
import { Topbar } from "./components/Topbar";
import { Hero } from "./sections/Hero";
import { Foundations } from "./sections/Foundations";
import { Color } from "./sections/Color";
import { Typography } from "./sections/Type";
import { Logos } from "./sections/Logos";
import { Elevation } from "./sections/Elevation";
import { Icons } from "./sections/Icons";
import { ComponentIndex } from "./sections/ComponentIndex";
import { LessonMap } from "./sections/LessonMap";
import { SkillCards, MotionShowcase } from "./sections/SkillCards";
import { Components } from "./sections/Components";
import { Motion } from "./sections/Motion";
import { Patterns } from "./sections/Patterns";
import { Pages } from "./sections/Pages";
import { Screens } from "./sections/Screens";
import { Audit } from "./sections/Audit";
import { Footer } from "./sections/Footer";
import { BrandGuide } from "./sections/BrandGuide";
import { Changelog } from "./sections/Changelog";
import { Theming } from "./sections/Theming";
import { Devtools, Handoff, Roadmap, Sitemap } from "./sections/Devtools";
import { NAV } from "./data";

export default function App() {
  const [active, setActive] = useState<string>("foundations");

  useEffect(() => {
    const onHash = () => {
      const id = location.hash.replace("#", "");
      if (id && NAV.some((n) => n.id === id)) setActive(id);
    };
    onHash();
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  return (
    <div className="min-h-screen bg-bg">
      <Topbar active={active} setActive={setActive} />
      <Hero />
      <Foundations />
      <Color />
      <Typography />
      <Logos />
      <Elevation />
      <Icons />
      <ComponentIndex />
      <LessonMap />
      <SkillCards />
      <MotionShowcase />
      <Components />
      <Motion />
      <Patterns />
      <Pages />
      <Screens />
      <Audit />
      <BrandGuide />
      <Changelog />
      <Theming />
      <Devtools />
      <Handoff />
      <Roadmap />
      <Sitemap />
      <Footer />
    </div>
  );
}
