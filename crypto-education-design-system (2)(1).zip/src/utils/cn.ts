import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Tailwind-aware className combiner.
 * Resolves conflicts (e.g. `px-4 px-6` → `px-6`) and supports conditional values.
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** Conditional class shorthand: cnIf(condition, "class") */
export function cnIf(condition: boolean | null | undefined, classes: string): string {
  return condition ? classes : "";
}
