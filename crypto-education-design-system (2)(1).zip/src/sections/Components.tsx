import { useState } from "react";
import {
  Section,
  Panel,
  Button,
  Chip,
  Progress,
  Ring,
  Tabs,
  Code,
  Toast,
  EmptyState,
} from "../components/ui";
import {
  IconCube,
  IconBolt,
  IconArrow,
  IconSearch,
  IconX,
  IconCheck,
  IconClock,
  IconFlame,
  IconGift,
  IconWallet,
  IconTrophy,
} from "../components/Icons";

export function Components() {
  const [variant, setVariant] = useState(0);
  const [size, setSize] = useState(1);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [toggle, setToggle] = useState(true);
  const [toasts, setToasts] = useState<number[]>([]);
  const variants = ["primary", "secondary", "outline", "danger", "premium"] as const;
  const sizes = ["sm", "md", "lg"] as const;

  const push = () => {
    const id = Date.now();
    setToasts((t) => [...t, id]);
    setTimeout(() => setToasts((t) => t.filter((x) => x !== id)), 2800);
  };

  return (
    <Section
      id="components"
      index="07"
      eyebrow="Components"
      icon={<IconCube size={17} />}
      title="Tactile, accessible, on-brand"
      desc="52 components. Every interactive element ships with hover, press, focus-visible, loading and disabled states. Try the playground, then fire a toast."
    >
      <div className="el-3 grid gap-6 rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-6 lg:grid-cols-[1fr_320px]">
        <div className="el-press flex min-h-[210px] items-center justify-center rounded-3xl bg-bg2/80 p-8 grid-lines">
          <Button
            variant={variants[variant]}
            size={sizes[size]}
            loading={loading}
            disabled={disabled}
            iconRight={<IconArrow size={17} />}
          >
            Start lesson
          </Button>
        </div>
        <div className="space-y-4">
          <div>
            <p className="mono mb-2 text-[10px] uppercase tracking-[0.2em] text-dim">
              variant
            </p>
            <div className="flex flex-wrap gap-2">
              {variants.map((v, i) => (
                <Chip
                  key={v}
                  tone={i === variant ? "teal" : "dim"}
                  active={i === variant}
                  onClick={() => setVariant(i)}
                >
                  {v}
                </Chip>
              ))}
            </div>
          </div>
          <div>
            <p className="mono mb-2 text-[10px] uppercase tracking-[0.2em] text-dim">
              size
            </p>
            <Tabs items={["sm", "md", "lg"]} value={size} onChange={setSize} />
          </div>
          <div className="flex gap-2">
            <Chip
              tone={loading ? "amber" : "dim"}
              active={loading}
              onClick={() => setLoading((v) => !v)}
            >
              loading
            </Chip>
            <Chip
              tone={disabled ? "down" : "dim"}
              active={disabled}
              onClick={() => setDisabled((v) => !v)}
            >
              disabled
            </Chip>
          </div>
          <Code>{`<Button variant="${variants[variant]}" size="${sizes[size]}"${loading ? " loading" : ""}${disabled ? " disabled" : ""}>
  Start lesson
</Button>`}</Code>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel label="Buttons">
          <div className="space-y-3">
            <Button full icon={<IconBolt size={17} />}>Start lesson</Button>
            <Button full variant="secondary">Save for later</Button>
            <Button full variant="outline">Preview module</Button>
            <Button full variant="premium" icon={<IconGift size={17} />}>Go Premium</Button>
            <Button full variant="danger">Reset progress</Button>
            <div className="flex gap-2">
              <Button size="sm" variant="ghost">Ghost</Button>
              <Button size="sm" loading>Loading</Button>
              <Button size="sm" disabled>Disabled</Button>
            </div>
          </div>
        </Panel>

        <Panel label="Inputs & controls">
          <div className="space-y-4">
            <div>
              <label className="mono text-[10px] uppercase tracking-[0.2em] text-dim">email</label>
              <div className="el-press mt-1.5 rounded-2xl border border-line bg-bg2 px-4 py-3 text-[14px] text-ink">
                alex@signal.io
              </div>
            </div>
            <div>
              <label className="mono text-[10px] uppercase tracking-[0.2em] text-teal">focused</label>
              <div className="el-ring mt-1.5 flex items-center gap-2 rounded-2xl border border-teal/60 bg-bg2 px-4 py-3 text-[14px] text-ink">
                <IconSearch size={15} className="text-teal" /> seed phrase
                <span className="ml-0.5 h-4 w-px animate-pulse bg-teal" />
              </div>
            </div>
            <div>
              <label className="mono text-[10px] uppercase tracking-[0.2em] text-down">error</label>
              <div className="el-press mt-1.5 rounded-2xl border border-down bg-down/[0.08] px-4 py-3 text-[14px] text-down">
                0xInvalidAddress
              </div>
              <p className="mt-1.5 flex items-center gap-1.5 text-[11.5px] text-down">
                <IconX size={12} /> Checksum failed.
              </p>
            </div>
            <div className="el-1 flex items-center justify-between rounded-2xl border border-line bg-card px-4 py-3">
              <span className="text-[14px] text-ink">Price alerts</span>
              <button
                onClick={() => setToggle((t) => !t)}
                className={`el-press relative h-7 w-12 rounded-full transition-colors duration-300 ${toggle ? "bg-teal/90" : "bg-line"}`}
              >
                <span
                  className={`el-2 absolute top-0.5 h-6 w-6 rounded-full bg-white transition-all duration-300 ease-[cubic-bezier(.22,1,.36,1)] ${toggle ? "left-[22px]" : "left-0.5"}`}
                />
              </button>
            </div>
          </div>
        </Panel>

        <Panel label="Feedback & status">
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              <Chip tone="up" icon={<IconCheck size={12} />}>Correct</Chip>
              <Chip tone="down" icon={<IconX size={12} />}>Wrong</Chip>
              <Chip tone="wait" icon={<IconClock size={12} />}>Pending</Chip>
              <Chip tone="amber" icon={<IconFlame size={12} />}>Streak 12</Chip>
              <Chip tone="pink" icon={<IconGift size={12} />}>Premium</Chip>
              <Chip tone="lime">+50 XP</Chip>
            </div>
            <div className="el-2 flex items-center gap-2.5 rounded-2xl border border-up/40 bg-up/10 p-3 text-[13px] text-up">
              <IconCheck size={16} /> Lesson completed — 50 XP added.
            </div>
            <div className="el-2 flex items-center gap-2.5 rounded-2xl border border-wait/40 bg-wait/10 p-3 text-[13px] text-wait">
              <IconClock size={16} /> Transaction confirming on-chain…
            </div>
            <div className="space-y-2 pt-1">
              <Progress value={72} />
              <Progress value={44} tone="amber" />
              <Progress value={90} tone="lime" />
            </div>
            <div className="flex items-center gap-4 pt-1">
              <Ring value={34} size={76} label="course" />
              <Ring value={82} size={76} label="level" />
              <div className="flex-1 space-y-2">
                <div className="shimmer h-3 rounded-full" />
                <div className="shimmer h-3 w-2/3 rounded-full" />
              </div>
            </div>
          </div>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel label="Toast & snackbar">
          <div className="relative space-y-3">
            <Button size="sm" variant="secondary" onClick={push} icon={<IconCheck size={14} />}>
              Fire toast
            </Button>
            <div className="flex min-h-[86px] flex-col gap-2">
              {toasts.slice(-2).map((t) => (
                <Toast key={t} text="Progress saved · sync complete" />
              ))}
              {toasts.length === 0 && (
                <div className="el-press flex h-[58px] items-center justify-center rounded-2xl border border-dashed border-line bg-bg2/60 text-[11.5px] text-dim">
                  No active toasts
                </div>
              )}
            </div>
          </div>
        </Panel>

        <Panel label="Skeleton & empty state">
          <div className="space-y-2.5">
            <div className="flex items-center gap-3">
              <div className="shimmer h-10 w-10 rounded-2xl" />
              <div className="flex-1 space-y-2">
                <div className="shimmer h-3 rounded-full" />
                <div className="shimmer h-3 w-1/2 rounded-full" />
              </div>
            </div>
            <div className="shimmer h-[54px] rounded-2xl" />
          </div>
          <div className="mt-4">
            <EmptyState
              Icon={IconWallet}
              title="No assets yet"
              body="Connect a wallet to track your portfolio."
              cta={
                <Button size="sm" icon={<IconArrow size={14} />}>
                  Connect
                </Button>
              }
            />
          </div>
        </Panel>

        <Panel label="Bottom sheet & stepper">
          <div className="el-press relative h-[168px] overflow-hidden rounded-2xl border border-line bg-bg2 p-3">
            <div className="el-glow mx-auto h-1 w-10 rounded-full bg-teal/40" />
            <div className="el-3 mt-3 rounded-2xl border border-line bg-gradient-to-b from-card to-surface p-3">
              <p className="font-display text-[13px] font-bold text-ink">Confirm transaction</p>
              <p className="mt-1 text-[11px] text-dim">Swap 0.05 BTC → 1.94 ETH</p>
              <div className="mt-3 flex gap-2">
                <Button size="sm" variant="secondary" full>Cancel</Button>
                <Button size="sm" full>Confirm</Button>
              </div>
            </div>
            <div className="el-2 absolute inset-x-3 -bottom-2 flex items-center justify-between rounded-2xl border border-line bg-card px-3 py-2">
              {["Wallet", "Review", "Sign", "Done"].map((s, i) => (
                <div key={s} className="flex flex-1 flex-col items-center gap-1">
                  <span
                    className={`flex h-4 w-4 items-center justify-center rounded-full text-[8px] font-bold ${
                      i < 2 ? "bg-teal text-[#04241f]" : "border border-line text-dim"
                    }`}
                  >
                    {i < 2 ? "✓" : i + 1}
                  </span>
                  <span className="mono text-[8px] text-dim">{s}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="el-1 mt-3 flex items-center gap-3 rounded-2xl border border-line/60 bg-bg2 p-3">
            <IconTrophy className="text-lime" size={18} />
            <p className="mono flex-1 text-[11px] text-dim">
              52 / 52 components documented
            </p>
          </div>
        </Panel>
      </div>
    </Section>
  );
}
