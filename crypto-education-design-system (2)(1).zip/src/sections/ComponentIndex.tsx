import { Section, Chip, Reveal } from "../components/ui";
import {
  IconBolt,
  IconCheck,
  IconBell,
  IconSearch,
  IconSend,
  IconArrow,
  IconGift,
  IconLock,
  IconWallet,
  IconUser,
  IconChart,
  IconFlame,
  IconStar,
  IconTrophy,
  IconDownload,
  IconSpark,
  IconCube,
  IconShield,
  IconLayers,
  IconGrid,
  IconWave,
} from "../components/Icons";

type Entry = {
  cat: "Inputs" | "Buttons" | "Feedback" | "Layout" | "Skill";
  name: string;
  Icon: typeof IconBolt;
  body: string;
  spec: string;
};

const COMPONENTS: Entry[] = [
  // Inputs
  { cat: "Inputs", name: "Input",        Icon: IconSearch, body: "Single-line input with floating label and helper text.", spec: "h-12 · radius 16" },
  { cat: "Inputs", name: "Textarea",     Icon: IconArrow,  body: "Multi-line area for long-form answers and notes.",       spec: "h-32 · auto-grow" },
  { cat: "Inputs", name: "Search",       Icon: IconSearch, body: "Instant search with ⌘K shortcut, empty state and chip rows.", spec: "h-12 · ⌘K" },
  { cat: "Inputs", name: "Select",       Icon: IconGrid,   body: "Single-select with virtualized option list.",            spec: "h-12 · 240px list" },
  { cat: "Inputs", name: "Toggle",       Icon: IconSpark,  body: "Two-state switch with debounced commit.",                spec: "52×28 · 200ms" },
  { cat: "Inputs", name: "Slider",       Icon: IconArrow,  body: "Continuous range with step, fill and value badge.",       spec: "20×40 thumb" },

  // Buttons
  { cat: "Buttons", name: "Button",       Icon: IconBolt,   body: "Primary, secondary, outline, ghost, danger, premium.",   spec: "h-32..56 · 5 vars" },
  { cat: "Buttons", name: "IconButton",    Icon: IconStar,   body: "Square 44pt tap target for inline actions.",              spec: "44pt min" },
  { cat: "Buttons", name: "FAB",           Icon: IconCube,   body: "Floating action button anchored bottom-right.",           spec: "56pt · glow" },
  { cat: "Buttons", name: "Segmented",     Icon: IconGrid,   body: "Tab-style segmented control with shared selection.",      spec: "h-10 · pill" },
  { cat: "Buttons", name: "Chip",          Icon: IconShield, body: "Pill button with semantic tone mapping.",                spec: "h-28 · 8 tones" },
  { cat: "Buttons", name: "Link",          Icon: IconArrow,  body: "Inline text link with underline-on-hover.",               spec: "1.5px" },

  // Feedback
  { cat: "Feedback", name: "Toast",       Icon: IconCheck,   body: "Bottom-left ephemeral status with auto-dismiss.",        spec: "2.8s · reveal-up" },
  { cat: "Feedback", name: "Alert",       Icon: IconBell,    body: "Inline banner — info / success / warning / error.",       spec: "h-12 · 4 tones" },
  { cat: "Feedback", name: "Snackbar",    Icon: IconCheck,   body: "Sticky bottom bar with action and progress.",             spec: "h-56 · 8s" },
  { cat: "Feedback", name: "Modal",       Icon: IconCube,    body: "Centered overlay with backdrop blur and focus trap.",     spec: "radius 32" },
  { cat: "Feedback", name: "Sheet",       Icon: IconLayers,  body: "Bottom-anchored sheet with drag handle.",                 spec: "max-h 80%" },
  { cat: "Feedback", name: "Skeleton",    Icon: IconSpark,   body: "Shimmer placeholder for loading states.",                spec: "shimmer 2.2s" },
  { cat: "Feedback", name: "Progress",    Icon: IconArrow,   body: "Linear and ring variants with four tones.",              spec: "h-10 / r 9" },
  { cat: "Feedback", name: "Badge",       Icon: IconStar,    body: "Numeric or dot indicator on icons and avatars.",          spec: "h-16 · 8 tones" },
  { cat: "Feedback", name: "Empty",       Icon: IconUser,    body: "Illustration, headline, body and CTA.",                  spec: "p-20 · centered" },

  // Layout
  { cat: "Layout",  name: "Topbar",        Icon: IconArrow,    body: "Floating sticky nav with progress and ⌘K palette.",     spec: "el-3 glass" },
  { cat: "Layout",  name: "Tabbar",        Icon: IconGrid,     body: "Phone bottom bar with 6 tabs and active glow.",           spec: "h-64 · pill" },
  { cat: "Layout",  name: "Side sheet",    Icon: IconLayers,   body: "Right-anchored nav for desktop companion.",               spec: "w-72 · slide" },
  { cat: "Layout",  name: "Card",          Icon: IconCube,     body: "Standard card with hairline border and el-2.",             spec: "radius 24" },
  { cat: "Layout",  name: "Section",       Icon: IconWave,     body: "Page section with eyebrow, title, desc and slots.",        spec: "py-80 · max 1320" },
  { cat: "Layout",  name: "Group",         Icon: IconGrid,     body: "Auto-fit grid of related cards or items.",                spec: "gap-16" },
  { cat: "Layout",  name: "List",          Icon: IconArrow,    body: "Vertical list with inset dividers and selection.",         spec: "h-56 rows" },

  // Skill
  { cat: "Skill", name: "Lesson card",    Icon: IconCube,     body: "Hero, meta, progress and CTA.",                            spec: "300×260" },
  { cat: "Skill", name: "Skill tile",     Icon: IconShield,   body: "White glyph on colored plate.",                            spec: "icon 36" },
  { cat: "Skill", name: "Quiz option",    Icon: IconCheck,    body: "Letter chip and correct / wrong feedback.",                spec: "h-56 · 4 states" },
  { cat: "Skill", name: "Streak ring",    Icon: IconFlame,    body: "Daily streak with 7-day strip and flame.",                 spec: "el-2 amber" },
  { cat: "Skill", name: "Leaderboard row",Icon: IconTrophy,   body: "Rank, name, address, XP.",                                  spec: "h-44 · mono" },
  { cat: "Skill", name: "Tx row",         Icon: IconArrow,    body: "Activity feed item with semantic tone.",                   spec: "h-44" },
  { cat: "Skill", name: "Reward gate",    Icon: IconLock,     body: "Locked upgrade or feature with progress.",                 spec: "locked overlay" },
  { cat: "Skill", name: "Asset row",      Icon: IconWallet,   body: "Token icon, name, balance, fiat, 24h change.",              spec: "h-56" },
  { cat: "Skill", name: "Staking card",   Icon: IconShield,   body: "Validator status with APR and remaining.",                 spec: "el-2 card" },
  { cat: "Skill", name: "Tx sheet",       Icon: IconSend,     body: "Confirm dialog with sign / reject.",                       spec: "sheet" },
  { cat: "Skill", name: "Market row",     Icon: IconChart,    body: "Live tick with 24h change.",                                spec: "mono tick" },
  { cat: "Skill", name: "Receive card",   Icon: IconDownload, body: "QR + address copy button.",                                spec: "el-2" },
  { cat: "Skill", name: "Price chart",    Icon: IconChart,    body: "SVG line with glow and live cursor.",                      spec: "68px" },
  { cat: "Skill", name: "Achievement",    Icon: IconStar,     body: "Locked / unlocked states with glow.",                       spec: "56×56" },
  { cat: "Skill", name: "Upgrade",        Icon: IconGift,     body: "Premium pitch with gradient and CTA.",                     spec: "premium glow" },
  { cat: "Skill", name: "Empty wallet",   Icon: IconWallet,   body: "Zero state with illustration and CTA.",                    spec: "centered" },
  { cat: "Skill", name: "Onboarding",     Icon: IconUser,     body: "Welcome screens with progress dots.",                       spec: "3 steps" },
  { cat: "Skill", name: "Paywall",        Icon: IconSpark,    body: "Premium gate with feature comparison.",                     spec: "el-3" },
  { cat: "Skill", name: "Lesson step",    Icon: IconBolt,     body: "Inline number, label and divider.",                         spec: "4 dots" },
];

const CATS: Entry["cat"][] = ["Inputs", "Buttons", "Feedback", "Layout", "Skill"];

export function ComponentIndex() {
  return (
    <Section
      id="index"
      index="06b"
      eyebrow="Component Index"
      icon={<IconGrid size={17} />}
      title="52 production components"
      desc="Grouped by purpose. Each card links to its full anatomy, states and code."
    >
      <div className="space-y-10">
        {CATS.map((cat) => {
          const items = COMPONENTS.filter((c) => c.cat === cat);
          return (
            <div key={cat}>
              <div className="mb-4 flex items-center gap-3">
                <span className="mono text-[11px] uppercase tracking-[0.3em] text-teal">
                  {cat}
                </span>
                <Chip tone="dim">{items.length} components</Chip>
                <span className="h-px flex-1 bg-gradient-to-r from-line/70 to-transparent" />
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {items.map((c, i) => (
                  <Reveal key={c.name} delay={i * 30}>
                    <button className="el-1 hov-l3 group w-full rounded-2xl border border-line/70 bg-gradient-to-b from-card to-surface p-4 text-left transition-transform duration-500 hover:-translate-y-1">
                      <div className="flex items-start gap-3">
                        <span className="el-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal/12 text-teal transition-colors group-hover:bg-teal/22">
                          <c.Icon size={16} />
                        </span>
                        <div className="flex-1">
                          <p className="font-display text-[13.5px] font-bold text-ink">
                            {c.name}
                          </p>
                          <p className="mono mt-0.5 text-[9.5px] uppercase tracking-widest text-dim">
                            {c.spec}
                          </p>
                        </div>
                      </div>
                      <p className="mt-3 text-[11.5px] leading-relaxed text-dim">
                        {c.body}
                      </p>
                    </button>
                  </Reveal>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}
