import { useState } from "react";
import { Section, Panel, Chip, Button, Progress, Code } from "../components/ui";
import {
  IconBolt,
  IconCheck,
  IconArrow,
  IconCube,
  IconShield,
  IconChart,
  IconUser,
  IconStar,
  IconGift,
  IconLock,
  IconFlame,
  IconClock,
  IconX,
  IconSpark,
  IconTrophy,
  IconLayers,
  IconSearch,
  IconBook,
} from "../components/Icons";

export function Pages() {
  return (
    <Section
      id="pages"
      index="08b"
      eyebrow="Full pages"
      icon={<IconLayers size={17} />}
      title="Beyond the components — full screens"
      desc="Onboarding, paywall, error, success, search and lesson detail. Each page is self-contained and uses nothing outside the system."
    >
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel label="Onboarding" className="!p-0 overflow-hidden">
          <OnboardingPage />
        </Panel>

        <Panel label="Paywall" className="!p-0 overflow-hidden">
          <PaywallPage />
        </Panel>

        <Panel label="Search & discovery" className="!p-0 overflow-hidden">
          <SearchPage />
        </Panel>

        <Panel label="Lesson detail" className="!p-0 overflow-hidden">
          <LessonDetailPage />
        </Panel>

        <Panel label="Transaction confirm" className="!p-0 overflow-hidden">
          <TxConfirmPage />
        </Panel>

        <Panel label="Achievements" className="!p-0 overflow-hidden">
          <AchievementsPage />
        </Panel>
      </div>

      <div className="mt-4">
        <Panel label="Spec">
          <Code lang="ts">{`// Full pages are composed entirely of system primitives.
// Each page renders inside <Panel> to inherit the standard padding and elevation.
// Pages: onboarding (3-step), paywall, search, lesson, tx, achievements.`}</Code>
        </Panel>
      </div>
    </Section>
  );
}

/* ====== Onboarding ====== */
function OnboardingPage() {
  const [step, setStep] = useState(0);
  const slides = [
    { I: IconCube,    h: "Learn by doing",      b: "Bite-sized lessons with live simulations and quizzes." },
    { I: IconChart,   h: "Track real markets",  b: "Live tickers, watchlists and portfolio in one place." },
    { I: IconShield,  h: "Stay safe",           b: "Best-practice security prompts and seed-phrase trainer." },
  ];
  const s = slides[step];
  const S = s.I;
  return (
    <div className="space-y-5 p-6">
      <div className="flex items-center justify-between">
        <span className="mono text-[10px] uppercase tracking-widest text-dim">
          Onboarding
        </span>
        <button className="text-[12px] text-dim">Skip</button>
      </div>

      <div className="el-3 relative mx-auto flex h-[170px] max-w-[300px] items-center justify-center overflow-hidden rounded-3xl bg-gradient-to-br from-teal/30 to-wait/20">
        <div className="absolute inset-0 grid-lines opacity-50" />
        <S className="text-teal" size={70} />
      </div>

      <div className="text-center">
        <p className="font-display text-[22px] font-bold text-ink">{s.h}</p>
        <p className="mt-1.5 text-[13px] text-dim">{s.b}</p>
      </div>

      <div className="flex justify-center gap-1.5">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setStep(i)}
            className={`h-1.5 rounded-full transition-all duration-500 ${
              i === step ? "w-7 bg-teal" : "w-2 bg-line"
            }`}
          />
        ))}
      </div>

      <div className="flex gap-2">
        <Button full variant="secondary" onClick={() => setStep((x) => Math.max(0, x - 1))}>
          Back
        </Button>
        <Button
          full
          onClick={() => setStep((x) => Math.min(slides.length - 1, x + 1))}
          iconRight={<IconArrow size={16} />}
        >
          {step === slides.length - 1 ? "Start" : "Next"}
        </Button>
      </div>
    </div>
  );
}

/* ====== Paywall ====== */
function PaywallPage() {
  return (
    <div className="relative space-y-4 p-6">
      <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-pink/20 blur-3xl" />
      <Chip tone="pink" icon={<IconStar size={12} />}>Premium</Chip>
      <p className="font-display text-[26px] font-bold leading-tight text-ink">
        Go Premium — unlock DeFi and trading tracks.
      </p>
      <div className="grid grid-cols-3 gap-2">
        {(
          [
            ["Starter", "$0",   "/mo",  "Free"],
            ["Pro",     "$7",   "/mo",  "Most popular"],
            ["Team",    "$19",  "/mo",  "Shared seat"],
          ] as [string, string, string, string][]
        ).map(([n, p, u, sub]) => (
          <div
            key={n}
            className={`el-press rounded-2xl border p-3 text-center ${
              n === "Pro"
                ? "border-pink/50 bg-pink/10"
                : "border-line/70 bg-card"
            }`}
          >
            <p className="font-display text-[12px] font-bold text-ink">{n}</p>
            <p className="font-display mt-1 text-[20px] font-bold text-ink">
              {p}
              <span className="text-[10px] text-dim">{u}</span>
            </p>
            <p className="mt-1 text-[10px] text-dim">{sub}</p>
          </div>
        ))}
      </div>
      <ul className="space-y-1.5 text-[12px] text-dim">
        {["Advanced DeFi track", "Real-time portfolio", "Premium support", "No ads"].map((f) => (
          <li key={f} className="flex items-center gap-2">
            <IconCheck size={13} className="text-teal" /> {f}
          </li>
        ))}
      </ul>
      <Button full variant="premium" icon={<IconGift size={15} />}>
        Start 7-day trial
      </Button>
      <p className="text-center text-[10.5px] text-dim">
        Cancel anytime · No hidden fees
      </p>
    </div>
  );
}

/* ====== Search ====== */
function SearchPage() {
  const [q, setQ] = useState("defi");
  const items = [
    { I: IconBook,    t: "DeFi primitives",       sub: "Track · Intermediate",  chip: "lesson" },
    { I: IconChart,   t: "Liquidity pools",       sub: "Lesson · 14 min",       chip: "lesson" },
    { I: IconShield,  t: "Wallet safety",         sub: "Quiz · 5 min",          chip: "quiz"   },
    { I: IconUser,    t: "Alex Nova",             sub: "Learner · Level 7",     chip: "people" },
    { I: IconCube,    t: "Validator #3241",      sub: "Trending",              chip: "people" },
  ];
  const filtered = items.filter((i) => i.t.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="space-y-4 p-6">
      <div className="el-press flex items-center gap-2 rounded-2xl border border-teal/40 bg-bg2 px-3 py-2.5 text-[13px] text-ink">
        <IconSearch size={14} className="text-teal" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="flex-1 bg-transparent outline-none placeholder:text-dim"
          placeholder="Search lessons, quizzes, people…"
        />
        <span className="mono text-[10px] text-dim">{filtered.length}</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {["defi", "wallet", "trading", "nft", "stake"].map((tag) => (
          <Chip
            key={tag}
            tone={q === tag ? "teal" : "dim"}
            active={q === tag}
            onClick={() => setQ(tag)}
          >
            {tag}
          </Chip>
        ))}
      </div>
      <div className="space-y-2">
        {filtered.map((it) => {
          const I = it.I;
          return (
            <div
              key={it.t}
              className="el-press flex items-center gap-3 rounded-2xl border border-line/70 bg-card p-3"
            >
              <span className="el-1 flex h-9 w-9 items-center justify-center rounded-xl bg-teal/12 text-teal">
                <I size={16} />
              </span>
              <div className="flex-1">
                <p className="font-display text-[13px] font-bold text-ink">{it.t}</p>
                <p className="text-[10.5px] text-dim">{it.sub}</p>
              </div>
              <Chip tone={it.chip === "quiz" ? "amber" : it.chip === "people" ? "pink" : "teal"}>
                {it.chip}
              </Chip>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ====== Lesson detail ====== */
function LessonDetailPage() {
  const [progress, setProgress] = useState(34);
  return (
    <div className="space-y-4 p-6">
      <div className="flex items-center gap-3">
        <span className="el-1 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f]">
          <IconCube size={22} />
        </span>
        <div>
          <Chip tone="wait">Beginner · 8 of 24</Chip>
          <p className="font-display mt-1 text-[18px] font-bold text-ink">
            How blockchains reach consensus
          </p>
        </div>
      </div>

      <div>
        <Progress value={progress} height={7} />
        <div className="mt-1.5 flex justify-between text-[10px] text-dim">
          <span>1h 24m spent</span>
          <span className="mono">+50 XP</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {(
          [
            [IconBook,   "5 lessons",      "text-teal"],
            [IconBolt,   "3 quizzes",      "text-amber"],
            [IconTrophy, "1 challenge",    "text-pink"],
            [IconClock,  "≈ 12 min left",  "text-wait"],
          ] as [typeof IconBook, string, string][]
        ).map(([I, l, c]) => (
          <div
            key={l}
            className="el-press flex items-center gap-3 rounded-2xl bg-bg2 px-3 py-2.5 text-[12px]"
          >
            <I className={c} size={15} />
            <span className="text-ink">{l}</span>
          </div>
        ))}
      </div>

      <div className="el-2 rounded-2xl border border-line/70 bg-card p-3.5">
        <p className="mono text-[10px] uppercase tracking-widest text-dim">Up next</p>
        <p className="font-display mt-1 text-[14px] font-bold text-ink">
          Proof of Stake vs Proof of Work
        </p>
        <p className="mt-1 text-[11px] text-dim">
          Two consensus mechanisms, animated side-by-side.
        </p>
      </div>

      <div className="flex gap-2">
        <Button full variant="secondary">Restart</Button>
        <Button full iconRight={<IconArrow size={15} />}>Continue</Button>
      </div>

      <input
        type="range"
        min={0}
        max={100}
        value={progress}
        onChange={(e) => setProgress(+e.target.value)}
        className="el-press h-2 w-full appearance-none rounded-full bg-bg2"
        style={{ accentColor: "#2ee6c8" }}
      />
    </div>
  );
}

/* ====== Tx confirm ====== */
function TxConfirmPage() {
  return (
    <div className="space-y-4 p-6">
      <div className="flex items-center justify-between">
        <span className="mono text-[10px] uppercase tracking-widest text-dim">
          confirm · wallet
        </span>
        <IconX size={16} className="text-dim" />
      </div>
      <div className="el-3 relative overflow-hidden rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-4">
        <div className="flex items-center justify-between">
          <span className="font-display text-[12px] text-dim">You send</span>
          <span className="mono text-[12px] text-ink">0.05 ETH</span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <input
            className="el-press flex-1 rounded-2xl border border-line bg-bg2 px-3 py-2 text-[12px] text-ink"
            defaultValue="0.05"
          />
          <span className="font-display text-[14px] font-bold text-ink">ETH</span>
        </div>
        <div className="my-3 h-px bg-line/60" />
        <div className="flex items-center justify-between">
          <span className="font-display text-[12px] text-dim">Recipient</span>
          <span className="mono text-[12px] text-teal">0x8f2a…c41d</span>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px]">
          {[
            ["Network fee", "$0.42"],
            ["Total", "$170.18"],
            ["Speed", "fast"],
          ].map(([k, v]) => (
            <div key={k} className="el-press rounded-xl bg-bg2 px-2 py-1.5">
              <p className="mono text-[9px] uppercase tracking-widest text-dim">{k}</p>
              <p className="mt-1 font-bold text-ink">{v}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="el-2 flex items-center gap-2 rounded-2xl border border-wait/30 bg-wait/[0.08] p-3 text-[11.5px] text-wait">
        <IconShield size={13} /> You are signing a transfer, not an approval.
      </div>
      <div className="flex gap-2">
        <Button full variant="secondary">Reject</Button>
        <Button full>Sign</Button>
      </div>
    </div>
  );
}

/* ====== Achievements ====== */
function AchievementsPage() {
  const items = [
    ["First Wallet",   "Connect a wallet",        true,  IconShield],
    ["Block by Block", "Complete 5 lessons",      true,  IconCube],
    ["DeFi Curious",   "Open the DeFi track",     true,  IconChart],
    ["Speed Reader",   "Finish a quiz <30s",      true,  IconBolt],
    ["Vault Builder",  "Back up your seed",       false, IconLock],
    ["Top 10%",        "Reach XP 12000",          false, IconTrophy],
    ["Validator",      "Stake 100 ATOM",          false, IconSpark],
    ["Hodler",         "Hold a position 30d",     false, IconFlame],
  ] as const;
  return (
    <div className="space-y-4 p-6">
      <div className="flex items-center justify-between">
        <p className="font-display text-[18px] font-bold text-ink">Achievements</p>
        <Chip tone="lime" icon={<IconTrophy size={11} />}>4 / 8</Chip>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {items.map(([n, d, u, I]) => (
          <div
            key={n}
            className={`el-2 rounded-2xl border p-3 ${
              u
                ? "border-teal/40 bg-teal/[0.08]"
                : "border-line/70 bg-card"
            }`}
          >
            <div className="flex items-center gap-2">
              <span
                className={`flex h-9 w-9 items-center justify-center rounded-xl ${
                  u ? "bg-gradient-to-br from-[#63f6de] to-teal text-[#04241f]" : "bg-bg2 text-line"
                }`}
              >
                <I size={16} />
              </span>
              <div className="flex-1">
                <p className="font-display text-[12.5px] font-bold text-ink">{n}</p>
                <p className="text-[10px] text-dim">{d}</p>
              </div>
              {u ? (
                <IconCheck size={14} className="text-up" />
              ) : (
                <IconLock size={12} className="text-line" />
              )}
            </div>
            <div className="mt-2">
              <Progress value={u ? 100 : Math.floor(Math.random() * 80)} height={4} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
