import { useState } from "react";
import { Section, Panel, Swatch, Progress, Code } from "../components/ui";
import { IconPalette, IconCheck } from "../components/Icons";
import { COLORS, ACCENT_TOKENS } from "../tokens";

export function Color() {
  const [accent, setAccent] = useState(0);
  const acc = ACCENT_TOKENS[accent].hex;

  return (
    <Section
      id="color"
      index="02"
      eyebrow="Color"
      icon={<IconPalette size={17} />}
      title="Deep navy canvas, teal signal"
      desc="Four navy layers build depth without borders; teal is reserved for progress, primary action and success. Click any swatch to copy the hex."
    >
      <Panel className="!p-5">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
          {COLORS.map((c) => (
            <Swatch key={c.name} name={c.name} hex={c.hex} />
          ))}
        </div>
      </Panel>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel label="Semantic map">
          <div className="space-y-2.5 text-[13px]">
            {COLORS.slice(6).map((c) => (
              <div key={c.name} className="flex items-center gap-3">
                <span
                  className="el-1 h-6 w-6 shrink-0 rounded-lg"
                  style={{ background: c.hex }}
                />
                <span className="mono w-14 font-semibold text-ink">{c.name}</span>
                <span className="text-dim">{c.use}</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel
          label="Accent theming"
          action={
            <span
              className="mono text-[10px] uppercase tracking-widest"
              style={{ color: acc }}
            >
              {ACCENT_TOKENS[accent].name}
            </span>
          }
        >
          <div className="mb-4 flex gap-2">
            {ACCENT_TOKENS.map((a, i) => (
              <button
                key={a.name}
                onClick={() => setAccent(i)}
                aria-label={a.name}
                className="el-1 h-8 w-8 rounded-xl border transition-transform duration-300 hover:-translate-y-0.5"
                style={{
                  background: a.hex,
                  borderColor:
                    i === accent ? "#e8eef7" : "rgba(255,255,255,.1)",
                  boxShadow:
                    i === accent
                      ? `0 0 0 4px ${a.hex}33, 0 10px 22px -10px ${a.hex}`
                      : undefined,
                }}
              />
            ))}
          </div>
          <div
            className="el-3 rounded-2xl border bg-gradient-to-b from-card to-surface p-4"
            style={{ borderColor: `${acc}66` }}
          >
            <div className="flex items-center justify-between">
              <span
                className="mono text-[10px] uppercase tracking-widest"
                style={{ color: acc }}
              >
                module · defi
              </span>
              <span className="text-[10px] text-dim">
                {ACCENT_TOKENS[accent].role.toLowerCase()}
              </span>
            </div>
            <p className="font-display mt-2 text-[15px] font-bold text-ink">
              Liquidity pools explained
            </p>
            <div className="mt-3">
              <Progress value={64} tone="teal" height={7} />
            </div>
            <button
              className="font-display mt-4 w-full rounded-2xl py-2.5 text-[13px] font-bold transition-transform active:translate-y-[1px]"
              style={{
                background: `linear-gradient(180deg, ${acc}, ${acc}cc)`,
                color: "#04241f",
                boxShadow: `0 1px 0 rgba(255,255,255,.4) inset, 0 12px 26px -10px ${acc}aa`,
              }}
            >
              Continue lesson
            </button>
          </div>
          <p className="mono mt-3 text-[10.5px] leading-relaxed text-dim">
            --accent: {acc} → borders, glyphs, focus ring, progress fill.
          </p>
        </Panel>

        <Panel label="Contrast audit">
          <div className="space-y-2">
            {[
              ["ink / bg", "16.8"],
              ["dim / bg", "8.1"],
              ["teal / bg", "11.2"],
              ["bg / teal", "10.4"],
              ["up / bg", "9.0"],
            ].map(([a, b]) => (
              <div
                key={a}
                className="el-press flex items-center justify-between rounded-xl bg-bg2 px-3 py-2 text-[12px]"
              >
                <span className="text-dim">{a}</span>
                <span className="mono text-ink">{b}:1</span>
                <span className="flex items-center gap-1 rounded bg-up/15 px-1.5 py-0.5 text-[10px] font-bold text-up">
                  <IconCheck size={11} /> AAA
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-2">
            {[
              ["from-[#63f6de] to-teal", "action"],
              ["from-teal to-wait", "progress"],
              ["from-pink to-amber", "premium"],
              ["from-lime to-up", "reward"],
            ].map(([g, l]) => (
              <div
                key={l}
                className={`el-2 relative h-9 overflow-hidden rounded-xl bg-gradient-to-r ${g}`}
              >
                <span className="mono absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-black/55">
                  {l}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <div className="mt-4">
        <Panel label="Engineered scale">
          <Code lang="ts">{`export const signal = {
  color: {
    teal: "#2ee6c8",
    bg:   "#070c14",
    ink:  "#e8eef7",
    // 14 tokens total — see src/tokens
  },
} as const;`}</Code>
        </Panel>
      </div>
    </Section>
  );
}
