import { Section, Panel, Button, Chip, Progress } from "../components/ui";
import {
  IconBook,
  IconCube,
  IconArrow,
  IconClock,
  IconFlame,
  IconGift,
  IconLock,
  IconTrophy,
  IconShield,
  IconWave,
  IconBolt,
  IconChart,
} from "../components/Icons";

export function Patterns() {
  return (
    <Section
      id="patterns"
      index="09"
      eyebrow="Patterns"
      icon={<IconBook size={17} />}
      title="Learning mechanics"
      desc="Composed blocks that actually teach: lesson cards, live market rows, quiz feedback, streaks and reward gates."
    >
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel label="Lesson card" className="h-full">
          <div className="el-2 overflow-hidden rounded-2xl border border-line bg-bg2">
            <div className="grain relative flex h-28 items-center justify-center bg-gradient-to-br from-teal/45 to-wait/25">
              <span className="el-glow flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f]">
                <IconCube size={26} />
              </span>
            </div>
            <div className="p-4">
              <div className="flex gap-2">
                <Chip tone="wait">Beginner</Chip>
                <Chip tone="dim" icon={<IconClock size={12} />}>12 min</Chip>
              </div>
              <p className="font-display mt-3 text-[16px] font-bold leading-snug text-ink">
                How blockchains reach consensus
              </p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-dim">
                PoW vs PoS explained with a live validator simulation.
              </p>
              <div className="mt-4">
                <Button size="sm" full iconRight={<IconArrow size={15} />}>Continue</Button>
              </div>
            </div>
          </div>
        </Panel>

        <Panel label="Market rows & skeleton" className="h-full">
          <div className="space-y-2.5">
            {(
              [
                ["BTC", "+2.41%", "up" as const],
                ["SOL", "-3.08%", "down" as const],
                ["ETH", "pending", "wait" as const],
              ]
            ).map(([s, c, t]) => (
              <div
                key={s}
                className="el-1 flex items-center gap-3 rounded-2xl border border-line/60 bg-card px-3 py-3"
              >
                <span className="mono flex h-9 w-9 items-center justify-center rounded-full bg-bg2 text-[10px] font-bold text-teal">
                  {s}
                </span>
                <div className="flex-1">
                  <div className="h-2 w-24 rounded-full bg-line/70" />
                  <div className="mt-1.5 h-2 w-14 rounded-full bg-line/40" />
                </div>
                <Chip tone={t === "up" ? "up" : t === "down" ? "down" : "wait"}>{c}</Chip>
              </div>
            ))}
            <div className="shimmer h-[58px] rounded-2xl" />
            <div className="shimmer h-[58px] rounded-2xl" />
          </div>
        </Panel>

        <Panel label="Streak & reward gate" className="h-full">
          <div className="el-2 rounded-2xl border border-amber/30 bg-gradient-to-br from-[#3a2a12] to-surface p-4">
            <p className="font-display flex items-center gap-2 text-[28px] font-bold text-amber">
              <IconFlame size={24} /> 12
            </p>
            <p className="text-[12px] text-dim">day streak — keep it alive</p>
            <div className="mt-4 flex justify-between">
              {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
                <div
                  key={i}
                  className={`flex h-8 w-8 items-center justify-center rounded-xl text-[11px] font-bold ${
                    i < 5 ? "el-1 bg-amber/25 text-amber" : "border border-line text-dim"
                  }`}
                >
                  {d}
                </div>
              ))}
            </div>
          </div>
          <div className="el-2 mt-3 flex items-center gap-3 rounded-2xl border border-line bg-card p-3">
            <IconGift className="text-pink" size={20} />
            <p className="flex-1 text-[12px] text-dim">
              Unlock <span className="text-teal">Advanced DeFi</span> at 14 days
            </p>
            <IconLock className="text-line" size={16} />
          </div>
          <div className="el-2 mt-3 flex items-center gap-3 rounded-2xl border border-lime/30 bg-lime/[0.07] p-3">
            <IconTrophy className="text-lime" size={20} />
            <p className="flex-1 text-[12px] text-lime">Top 4% of learners this week</p>
          </div>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel label="Skill grid">
          <div className="grid grid-cols-2 gap-2.5">
            {(
              [
                ["Wallet Safety", IconShield, "from-teal/55 to-teal/20", 80],
                ["DeFi 101",      IconWave,   "from-wait/60 to-wait/20", 45],
                ["On-chain",      IconCube,   "from-pink/55 to-pink/20", 20],
                ["Trading",       IconChart,  "from-amber/60 to-amber/20", 62],
              ] as [string, typeof IconShield, string, number][]
            ).map(([t, Ic, c, p]) => (
              <div
                key={t}
                className="el-2 rounded-2xl border border-line/70 bg-gradient-to-b from-card to-surface p-3 transition-transform duration-400 hover:-translate-y-0.5"
              >
                <div
                  className={`el-1 mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br text-white ${c}`}
                >
                  <Ic size={17} />
                </div>
                <p className="font-display text-[12.5px] font-semibold text-ink">{t}</p>
                <p className="mb-2 mono text-[9.5px] text-dim">{p}% complete</p>
                <Progress value={p} height={5} tone={p > 70 ? "lime" : "teal"} />
              </div>
            ))}
          </div>
        </Panel>

        <Panel label="Activity feed">
          <div className="space-y-2">
            {(
              [
                { s: "Receive", who: "0x8f2a…c41d",    v: "+0.0084 ETH",  t: "12 min ago", tone: "up"   as const },
                { s: "Swap",    who: "ETH → USDC",      v: "-0.052 ETH",   t: "2 h ago",    tone: "dim"  as const },
                { s: "Stake",   who: "Validator #3241", v: "+12.4 ATOM",   t: "1 d ago",    tone: "lime" as const },
                { s: "Send",    who: "0x3a1f…009b",     v: "-50 USDC",     t: "3 d ago",    tone: "down" as const },
              ]
            ).map((r) => (
              <div
                key={r.who}
                className="el-press flex items-center gap-3 rounded-2xl bg-bg2 px-3 py-2.5 text-[12px]"
              >
                <span className="font-display w-12 text-ink">{r.s}</span>
                <span className="mono flex-1 text-dim">{r.who}</span>
                <span className={`mono font-bold ${r.tone === "up" ? "text-up" : r.tone === "down" ? "text-down" : r.tone === "lime" ? "text-lime" : "text-dim"}`}>
                  {r.v}
                </span>
                <span className="mono text-[10px] text-dim">{r.t}</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel label="Leaderboard & XP">
          <div className="space-y-2">
            {(
              [
                ["0x4d2a…99ff", "Alex Nova",    12400, 1],
                ["0xa0c1…7311", "Mia Solano",   11820, 2],
                ["0x77b9…ee02", "K. Watanabe",  11020, 3],
                ["0xfe18…44a7", "S. Okonkwo",    9930, 4],
                ["0x9c45…10de", "L. Pereira",    8740, 5],
              ] as [string, string, number, number][]
            ).map(([addr, name, xp, rank]) => (
              <div
                key={addr}
                className="el-press flex items-center gap-3 rounded-2xl bg-bg2 px-3 py-2.5 text-[12px]"
              >
                <span className={`mono flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-bold ${rank === 1 ? "bg-amber/25 text-amber" : "bg-line/40 text-dim"}`}>
                  {rank}
                </span>
                <span className="mono flex-1 text-ink">{name}</span>
                <span className="mono text-dim">{addr}</span>
                <span className="mono font-bold text-teal tabular-nums">{xp}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel label="Tx confirm">
          <div className="el-press relative h-[200px] overflow-hidden rounded-2xl border border-line bg-bg2 p-4">
            <div className="el-glow mx-auto h-1 w-10 rounded-full bg-teal/40" />
            <div className="el-3 mt-4 rounded-2xl border border-line bg-gradient-to-b from-card to-surface p-4">
              <div className="flex items-center justify-between">
                <span className="font-display text-[14px] font-bold text-ink">
                  Send 0.05 ETH
                </span>
                <Chip tone="amber" icon={<IconBolt size={11} />}>fast</Chip>
              </div>
              <div className="mt-3 space-y-2 text-[12px]">
                <Row k="To" v="0x8f2a…c41d" mono />
                <Row k="Network fee" v="$0.42" />
                <Row k="Total" v="$170.18" mono />
              </div>
              <div className="mt-4 flex gap-2">
                <Button full size="sm" variant="secondary">Reject</Button>
                <Button full size="sm">Sign</Button>
              </div>
            </div>
          </div>
        </Panel>

        <Panel label="Staking position">
          <div className="el-2 rounded-2xl border border-line/70 bg-gradient-to-b from-card to-surface p-4">
            <div className="flex items-center justify-between">
              <span className="font-display text-[14px] font-bold text-ink">
                Validating · Cosmos
              </span>
              <Chip tone="lime" icon={<IconShield size={11} />}>active</Chip>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[26px] font-bold text-ink tabular-nums">
                128.4
              </span>
              <span className="text-[12px] text-dim">ATOM staked</span>
            </div>
            <div className="mt-1 text-[12px] text-up">+0.84% · APR 14.6%</div>
            <div className="mt-4">
              <Progress value={72} tone="lime" />
              <p className="mono mt-1.5 text-[10.5px] text-dim">
                72% of unbonding period complete
              </p>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {[
                ["Earned", "+0.104 ATOM"],
                ["Remaining", "21 days"],
                ["Next payout", "in 4h"],
              ].map(([k, v]) => (
                <div
                  key={k}
                  className="el-press rounded-xl bg-bg2 px-3 py-2 text-center"
                >
                  <p className="mono text-[9.5px] uppercase tracking-widest text-dim">
                    {k}
                  </p>
                  <p className="mono mt-1 text-[12px] font-bold text-ink">{v}</p>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>
    </Section>
  );
}

function Row({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-dim">{k}</span>
      <span className={`${mono ? "mono" : ""} text-ink`}>{v}</span>
    </div>
  );
}
