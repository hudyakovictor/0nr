import { useState } from "react";
import { Section, Tabs } from "../components/ui";
import { Phone, PhoneApp, TABS } from "../components/Phone";
import { IconWallet } from "../components/Icons";

export function Screens() {
  const [tab, setTab] = useState(0);

  return (
    <Section
      id="screens"
      index="10"
      eyebrow="Screens"
      icon={<IconWallet size={17} />}
      title="Six flows, fully interactive"
      desc="Home, Learn, Quiz, Market, Wallet and Profile assembled strictly from the tokens above. Switch tabs inside the phone or use the segmented control."
    >
      <div className="mb-8 flex justify-center">
        <Tabs items={TABS.map((t) => t.label)} value={tab} onChange={setTab} />
      </div>
      <div className="flex flex-wrap items-start justify-center gap-10 lg:gap-14">
        <Phone caption={`${TABS[tab].label} · live`} glow="teal">
          <PhoneApp tab={tab} onTab={setTab} />
        </Phone>
        <div className="hidden opacity-70 xl:block">
          <Phone caption="Wallet · assets" glow="wait">
            <PhoneApp tab={4} onTab={() => {}} />
          </Phone>
        </div>
        <div className="hidden opacity-55 2xl:block">
          <Phone caption="Market · live price" glow="pink">
            <PhoneApp tab={3} onTab={() => {}} />
          </Phone>
        </div>
      </div>
    </Section>
  );
}
