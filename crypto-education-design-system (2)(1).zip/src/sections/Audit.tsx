import { Section, Panel, Progress, Ring, Counter, Code } from "../components/ui";
import { IconShield, IconGrid, IconCheck, IconMotion } from "../components/Icons";
import { COLORS, AUDIT } from "../tokens";
import { AUDIT_ROWS } from "../data";

export function Audit() {
  return (
    <Section
      id="audit"
      index="11"
      eyebrow="Audit & Handoff"
      icon={<IconShield size={17} />}
      title="Scored on 120 factors, shipped as tokens"
      desc="Independent rubric across clarity, hierarchy, contrast, ergonomics, motion safety, consistency and delight — plus the full token table for engineering handoff."
    >
      <div className="grid gap-4 lg:grid-cols-[1.05fr_1fr]">
        <Panel label="Audit breakdown">
          <div className="space-y-4">
            {AUDIT_ROWS.map(([l, v]) => (
              <div key={l}>
                <div className="mb-1.5 flex justify-between text-[12.5px]">
                  <span className="text-dim">{l}</span>
                  <span className="mono text-teal">{v}</span>
                </div>
                <Progress value={v} height={7} />
              </div>
            ))}
          </div>
        </Panel>

        <div className="grid gap-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Panel
              label="Overall"
              tone="teal"
              className="flex flex-col items-center justify-center"
            >
              <Ring value={94} size={132} stroke={12} label="score" />
              <p className="mt-3 text-center text-[12.5px] text-dim">
                <Counter to={9.4} decimals={1} /> / 10 across{" "}
                <Counter to={120} /> factors
              </p>
            </Panel>
            <div className="grid gap-4">
              {(
                [
                  ["44pt", "minimum tap target", IconGrid],
                  ["AAA",  "body text contrast", IconCheck],
                  ["100%", "reduced-motion safe", IconMotion],
                ] as [string, string, typeof IconGrid][]
              ).map(([v, l, Ic]) => (
                <Panel key={l} className="!p-4">
                  <div className="flex items-center gap-3">
                    <span className="el-1 flex h-10 w-10 items-center justify-center rounded-xl bg-teal/12 text-teal">
                      <Ic size={18} />
                    </span>
                    <div>
                      <p className="font-display text-[18px] font-bold text-ink">{v}</p>
                      <p className="text-[11.5px] text-dim">{l}</p>
                    </div>
                  </div>
                </Panel>
              ))}
            </div>
          </div>

          <Panel label="Token table">
            <div className="el-press overflow-hidden rounded-2xl border border-line/60">
              <div className="grid grid-cols-[1fr_1.1fr_1.4fr] bg-bg2 px-3 py-2 mono text-[10px] uppercase tracking-widest text-dim">
                <span>token</span>
                <span>value</span>
                <span>usage</span>
              </div>
              {COLORS.slice(0, 7).map((c, i) => (
                <div
                  key={c.name}
                  className={`grid grid-cols-[1fr_1.1fr_1.4fr] items-center px-3 py-2 text-[11.5px] ${
                    i % 2 ? "bg-card/40" : "bg-card/70"
                  }`}
                >
                  <span className="mono flex items-center gap-2 text-ink">
                    <span className="h-3 w-3 rounded" style={{ background: c.hex }} />
                    {c.name}
                  </span>
                  <span className="mono text-teal">{c.hex}</span>
                  <span className="text-dim">{c.use}</span>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <Code lang="ts">{`export const signal = {
  color: { teal: "${COLORS[6].hex}",
    bg: "${COLORS[0].hex}", ink: "${COLORS[13].hex}" },
  radius: { card: 24, control: 16,
    sheet: 32, device: 46 },
  shadow: ["el-1","el-2","el-3",
    "el-4","el-glow"],
  motion: { fast: 180, base: 280,
    slow: 420,
    ease: "cubic-bezier(.22,1,.36,1)" },
  audit:  { score: 9.4, factors: 120,
    tokens: 14, components: 52 },
} as const;`}</Code>
            </div>
          </Panel>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-4">
        {(
          [
            [AUDIT.tokens,       "Semantic tokens"],
            [AUDIT.icons,        "Line icons"],
            [AUDIT.components,   "Components"],
            [AUDIT.factors,      "Audited factors"],
          ] as [number, string][]
        ).map(([n, l]) => (
          <div
            key={l}
            className="el-2 rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-5"
          >
            <p className="font-display text-[40px] font-bold leading-none text-teal tabular-nums">
              {n}
            </p>
            <p className="mt-2 text-[12px] text-dim">{l}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}
