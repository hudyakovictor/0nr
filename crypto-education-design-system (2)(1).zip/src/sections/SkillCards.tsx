import { useState, useRef, useEffect } from "react";
import { Section, Panel, Chip } from "../components/ui";
import {
  IconShield,
  IconWave,
  IconCube,
  IconChart,
  IconStar,
  IconLock,
  IconBolt,
  IconArrow,
  IconClock,
  IconBook,
  IconCheck,
  IconFlame,
  IconTrophy,
} from "../components/Icons";

type Skill = {
  id: string;
  title: string;
  short: string;
  Icon: typeof IconShield;
  /** gradient plate for top of card */
  plate: string;
  /** solid color used by glow / accent */
  accent: string;
  tone: "teal" | "wait" | "pink" | "amber" | "lime" | "orange" | "red" | "green";
  progress: number;
  mins: number;
  lessons: number;
  xp: number;
  diff: "Beginner" | "Intermediate" | "Advanced";
  tags: string[];
  locked?: boolean;
  desc: string;
};

const SKILLS: Skill[] = [
  {
    id: "wallet",
    title: "Wallet Safety",
    short: "Seed phrases, signing, scam defence.",
    Icon: IconShield,
    plate: "linear-gradient(180deg,#34d3b4 0%,#103a37 100%)",
    accent: "#2ee6c8",
    tone: "teal",
    progress: 80,
    mins: 36,
    lessons: 8,
    xp: 1240,
    diff: "Beginner",
    tags: ["seed", "phishing"],
    desc: "Learn to manage private keys, recognise phishing attempts and use hardware wallets safely.",
  },
  {
    id: "defi",
    title: "DeFi 101",
    short: "LPs, swaps, yield — without the jargon.",
    Icon: IconWave,
    plate: "linear-gradient(180deg,#5aa9ff 0%,#142a55 100%)",
    accent: "#5aa9ff",
    tone: "wait",
    progress: 45,
    mins: 58,
    lessons: 12,
    xp: 1820,
    diff: "Intermediate",
    tags: ["AMM", "staking"],
    desc: "Understand AMMs, liquidity pools, lending markets and yield strategies with real simulations.",
  },
  {
    id: "onchain",
    title: "On-chain Detective",
    short: "Read block explorers like a Sherlock.",
    Icon: IconCube,
    plate: "linear-gradient(180deg,#ff4d94 0%,#4d1230 100%)",
    accent: "#ff4d94",
    tone: "pink",
    progress: 20,
    mins: 42,
    lessons: 9,
    xp: 720,
    diff: "Intermediate",
    tags: ["explorer", "tracing"],
    desc: "Follow transactions, decode calldata, identify contracts and trace fund flows.",
  },
  {
    id: "trading",
    title: "Trading 101",
    short: "Candlesticks, order books, risk.",
    Icon: IconChart,
    plate: "linear-gradient(180deg,#f0a64d 0%,#3a2210 100%)",
    accent: "#f0a64d",
    tone: "amber",
    progress: 62,
    mins: 64,
    lessons: 14,
    xp: 2100,
    diff: "Advanced",
    tags: ["candles", "risk"],
    desc: "Read price action, manage risk with stops and position sizing, and avoid common traps.",
  },
  {
    id: "nft",
    title: "NFT Fundamentals",
    short: "What makes a JPEG worth millions.",
    Icon: IconStar,
    plate: "linear-gradient(180deg,#b7f739 0%,#2a4012 100%)",
    accent: "#b7f739",
    tone: "lime",
    progress: 10,
    mins: 30,
    lessons: 7,
    xp: 480,
    diff: "Beginner",
    tags: ["erc-721", "royalties"],
    desc: "From provenance to royalties — get the conceptual model and avoid rug pulls.",
  },
  {
    id: "sec",
    title: "OpSec Pro",
    short: "Multi-sig, cold storage, OPSEC 101.",
    Icon: IconLock,
    plate: "linear-gradient(180deg,#eb635b 0%,#3a0f0d 100%)",
    accent: "#eb635b",
    tone: "red",
    progress: 0,
    mins: 80,
    lessons: 16,
    xp: 0,
    diff: "Advanced",
    tags: ["multisig", "cold"],
    desc: "Design secure custody workflows, set up multi-sig and run incident drills.",
    locked: true,
  },
];

const FILTERS = ["All", "Beginner", "Intermediate", "Advanced"] as const;

type Size = "lg" | "md" | "sm";
type Sizes = Record<Size, { w: number; h: number; icon: number; title: string; body: string; ringSize: number }>;

const SIZES: Sizes = {
  lg: { w: 380, h: 460, icon: 64, title: "text-[26px]", body: "text-[14px]",  ringSize: 80 },
  md: { w: 300, h: 380, icon: 52, title: "text-[20px]", body: "text-[12.5px]", ringSize: 64 },
  sm: { w: 220, h: 290, icon: 40, title: "text-[15px]", body: "text-[11.5px]", ringSize: 50 },
};

export function SkillCards() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const list = SKILLS.filter((s) => s.diff === filter || filter === "All");

  return (
    <Section
      id="skill"
      index="06d"
      eyebrow="Skill cards · 3 sizes"
      icon={<IconBolt size={17} />}
      title="Tall by design — large white icon, brand plate"
      desc="Three sizes side-by-side: hero (380×460), grid (300×380), and compact (220×290). Aspect ratio is taller than wide on every variant."
    >
      <div className="mb-5 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <Chip
            key={f}
            tone={filter === f ? "teal" : "dim"}
            active={filter === f}
            onClick={() => setFilter(f)}
          >
            {f} {f !== "All" && `· ${SKILLS.filter((s) => s.diff === f).length}`}
          </Chip>
        ))}
      </div>

      <div className="space-y-12">
        <SizeRow size="lg" label="Hero · 380×460" list={list.slice(0, 4)} />
        <SizeRow size="md" label="Grid · 300×380" list={list} />
        <SizeRow size="sm" label="Compact · 220×290" list={list} />
      </div>
    </Section>
  );
}

function SizeRow({
  size,
  label,
  list,
}: {
  size: Size;
  label: string;
  list: Skill[];
}) {
  const dims = SIZES[size];
  return (
    <div>
      <div className="mb-4 flex items-center gap-3">
        <span className="mono text-[11px] uppercase tracking-[0.3em] text-teal">
          {label}
        </span>
        <span className="h-px flex-1 bg-gradient-to-r from-line/70 to-transparent" />
        <Chip tone="dim">ratio {dims.w}×{dims.h}</Chip>
      </div>
      <div className="flex flex-wrap items-end gap-5">
        {list.map((s, i) => (
          <SkillCard skill={s} dims={dims} key={`${size}-${s.id}`} index={i} />
        ))}
      </div>
    </div>
  );
}

/* ============ Single card ============ */
function SkillCard({
  skill,
  dims,
  index,
}: {
  skill: Skill;
  dims: Sizes[Size];
  index: number;
}) {
  const I = skill.Icon;
  const [hover, setHover] = useState(false);
  const [justOpened, setJustOpened] = useState(false);
  const [burst, setBurst] = useState(false);
  const [confetti, setConfetti] = useState(false);
  const [xp, setXp] = useState(0);
  const cardRef = useRef<HTMLDivElement>(null);

  const open = () => {
    if (skill.locked) {
      cardRef.current?.classList.remove("shake");
      void cardRef.current?.offsetWidth;
      cardRef.current?.classList.add("shake");
      return;
    }
    setJustOpened(true);
    setBurst(true);
    setConfetti(true);
    setXp((x) => x + 50);
    setTimeout(() => setBurst(false), 700);
    setTimeout(() => setConfetti(false), 1500);
    setTimeout(() => setJustOpened(false), 900);
  };

  const p = skill.progress;

  return (
    <div
      ref={cardRef}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className="relative"
      style={{
        width: dims.w,
        height: dims.h,
        animation: `springIn 0.6s cubic-bezier(.34, 1.56, .64, 1) ${index * 60}ms both`,
      }}
    >
      {/* base — vivid color (was muddy) */}
      <div
        className="el-press relative h-full w-full overflow-hidden rounded-[28px]"
        style={{
          background: "#0a1120",
          border: "1px solid rgba(29,56,102,.85)",
          boxShadow:
            "0 1px 0 rgba(255,255,255,.08) inset, 0 24px 60px -22px rgba(0,0,0,1)",
        }}
      >
        {/* colored plate (large, taller than wide) */}
        <div
          className="relative grid place-items-center"
          style={{
            background: skill.plate,
            height: "52%",
          }}
        >
          {/* glow ring around icon */}
          <span
            className="absolute inset-0 flex items-center justify-center"
            aria-hidden
          >
            <span
              className="block rounded-[28px] opacity-50 blur-2xl"
              style={{
                width: dims.icon * 1.6,
                height: dims.icon * 1.6,
                background: skill.accent,
              }}
            />
          </span>

          {/* big white icon — game-like tile */}
          <span
            className={`relative flex items-center justify-center rounded-[22px] bg-white text-[#0a1120] ${
              hover ? "wobble" : ""
            } ${justOpened ? "level-up" : ""}`}
            style={{
              width: dims.icon + 12,
              height: dims.icon + 12,
              boxShadow:
                "0 1px 0 rgba(255,255,255,.7) inset, 0 -1px 0 rgba(0,0,0,.06) inset, 0 12px 24px -8px rgba(0,0,0,.55)",
            }}
          >
            <I size={dims.icon} strokeWidth={1.6} />
          </span>

          {/* locked badge */}
          {skill.locked && (
            <span className="absolute right-3 top-3 flex h-7 w-7 items-center justify-center rounded-full bg-black/45 text-white backdrop-blur">
              <IconLock size={13} />
            </span>
          )}

          {/* burst ring on open */}
          {burst && (
            <span
              className="burst pointer-events-none absolute inset-0 m-auto rounded-full"
              style={{
                width: dims.icon * 2.4,
                height: dims.icon * 2.4,
                background: `radial-gradient(circle, ${skill.accent} 0%, transparent 70%)`,
                left: `calc(50% - ${dims.icon * 1.2}px)`,
                top: `calc(50% - ${dims.icon * 1.2}px)`,
              }}
            />
          )}

          {/* confetti on open */}
          {confetti &&
            Array.from({ length: 12 }).map((_, i) => {
              const angle = (i / 12) * Math.PI * 2;
              const r = 120 + Math.random() * 60;
              const tx = Math.cos(angle) * r;
              const ty = Math.sin(angle) * r - 40;
              const colors = ["#2ee6c8", "#f0a64d", "#ff4d94", "#50c890", "#5aa9ff"];
              return (
                <span
                  key={i}
                  className="confetti-pop absolute"
                  style={{
                    left: "50%",
                    top: "50%",
                    width: 8,
                    height: 8,
                    borderRadius: 2,
                    background: colors[i % colors.length],
                    boxShadow: `0 0 10px ${colors[i % colors.length]}`,
                    transform: "rotate(0)",
                    ["--tx" as string]: `${tx}px`,
                    ["--ty" as string]: `${ty}px`,
                    animation: `confettiPop 0.3s ease forwards, confetti 1.2s ${i * 30}ms ease forwards`,
                  }}
                />
              );
            })}
        </div>

        {/* body */}
        <div className="flex h-[48%] flex-col gap-2 px-5 py-4">
          <div className="flex flex-wrap gap-1.5">
            <Chip tone={skill.tone as "teal"}>{skill.diff}</Chip>
            <Chip tone="dim" icon={<IconClock size={11} />}>
              {skill.mins} min
            </Chip>
            <Chip tone="dim" icon={<IconBook size={11} />}>
              {skill.lessons} lessons
            </Chip>
          </div>

          <h3 className={`font-display font-bold leading-tight text-ink ${dims.title}`}>
            {skill.title}
          </h3>
          <p className={`leading-relaxed text-dim ${dims.body}`}>{skill.desc}</p>

          <div className="mt-auto flex flex-wrap gap-1">
            {skill.tags.map((t) => (
              <span
                key={t}
                className="mono rounded-md border border-line/60 bg-bg2/70 px-2 py-0.5 text-[10px] text-dim"
              >
                #{t}
              </span>
            ))}
          </div>

          <div className="mt-2 flex items-end justify-between">
            <div className="flex items-center gap-3">
              <Ring value={p} size={dims.ringSize} stroke={5} />
              <div>
                <p className="mono text-[9px] uppercase tracking-widest text-dim">
                  Progress
                </p>
                <p className="mono text-[12px] font-bold text-teal">{p}%</p>
                <p className="mono mt-0.5 text-[10px] text-dim">+{skill.xp} XP</p>
              </div>
            </div>

            <button
              onClick={open}
              className={`pressable focus-ring font-display inline-flex items-center gap-1.5 rounded-2xl px-4 ${
                skill.locked
                  ? "h-10 bg-bg2 text-dim"
                  : skill.progress === 0
                    ? "el-glow h-11 bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f]"
                    : "el-2 h-11 border border-teal/40 bg-gradient-to-b from-[#0f3a37] to-card text-teal"
              } font-bold text-[13px]`}
            >
              {skill.locked ? "Locked" : skill.progress === 0 ? "Start" : "Continue"}
              {!skill.locked && <IconArrow size={14} />}
            </button>
          </div>

          {/* XP toast */}
          {xp > 0 && justOpened && (
            <div className="xp-rise pointer-events-none absolute right-4 top-2 rounded-full bg-gradient-to-b from-lime to-up px-3 py-1 text-[11px] font-black text-[#0a1120]">
              +50 XP
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============ Live progress ring (white plate version) ============ */
function Ring({
  value,
  size = 60,
  stroke = 6,
}: {
  value: number;
  size?: number;
  stroke?: number;
  label?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (c * value) / 100;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={`sr${size}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#2ee6c8" />
            <stop offset="100%" stopColor="#5aa9ff" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#1d3866" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`url(#sr${size})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={off}
          style={{
            transition: "stroke-dashoffset 0.9s cubic-bezier(.34, 1.56, .64, 1)",
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-[12px] font-bold text-ink">{value}%</span>
      </div>
    </div>
  );
}

/* ============ 2026 motion showcase ============ */
export function MotionShowcase() {
  const [trigger, setTrigger] = useState(0);
  useEffect(() => {
    if (trigger > 0) {
      const t = setTimeout(() => setTrigger(0), 2200);
      return () => clearTimeout(t);
    }
  }, [trigger]);

  return (
    <Section
      id="motion-2026"
      index="09b"
      eyebrow="Motion · VFX · Interaction"
      icon={<IconFlame size={17} />}
      title="Angry Birds × 2026 award-wining"
      desc="Every interaction has cause, weight and celebration. Tap a level-complete card to see the full VFX stack."
    >
      <div className="grid gap-4 lg:grid-cols-[1fr_1.4fr]">
        <Panel label="Live trigger">
          <div className="flex flex-col items-center gap-4 py-6">
            <LevelCompleteCard key={trigger} />

            <div className="flex flex-wrap items-center justify-center gap-2">
              <button
                onClick={() => setTrigger((v) => v + 1)}
                className="pressable focus-ring font-display h-12 rounded-2xl bg-gradient-to-b from-[#63f6de] to-teal px-6 text-[14px] font-bold text-[#04241f] el-glow"
              >
                <span className="flex items-center gap-2">
                  <IconBolt size={15} /> Complete level
                </span>
              </button>
              <button
                onClick={() => setTrigger((v) => v + 1)}
                className="pressable focus-ring font-display h-12 rounded-2xl border border-line bg-card px-5 text-[13px] font-bold text-ink"
              >
                Replay
              </button>
            </div>
            <p className="mono text-[10.5px] text-dim">
              keyframe count · 9  ·  particle count · 18  ·  spring · 0.34, 1.56, 0.64, 1
            </p>
          </div>
        </Panel>

        <Panel label="VFX library">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <FxTile name="springIn"   desc="entry pop with overshoot"   Icon={IconBolt} tone="teal" />
            <FxTile name="launchOut"  desc="shoot off-screen"           Icon={IconArrow} tone="pink" />
            <FxTile name="shake"      desc="error / locked"             Icon={IconLock}  tone="down" />
            <FxTile name="wobble"     desc="hover micro-bounce"         Icon={IconStar}  tone="amber" />
            <FxTile name="burst"      desc="halo ring on tap"           Icon={IconFlame} tone="amber" />
            <FxTile name="confetti"   desc="12-piece burst"             Icon={IconTrophy} tone="lime" />
            <FxTile name="xpRise"     desc="+50 XP floating toast"      Icon={IconBolt}  tone="teal" />
            <FxTile name="levelUp"    desc="hero card scale-up"         Icon={IconTrophy} tone="pink" />
            <FxTile name="glowPulse"  desc="looping CTA halo"           Icon={IconFlame} tone="teal" />
          </div>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel label="Spring easings">
          <div className="space-y-3">
            {(
              [
                ["out-expo",  "0.22, 1, 0.36, 1",      "Calm entry"],
                ["spring",    "0.34, 1.56, 0.64, 1",   "Overshoot"],
                ["out-quart", "0.165, 0.84, 0.44, 1",  "Snappy"],
                ["in-out",    "0.87, 0, 0.13, 1",      "Dramatic"],
              ] as [string, string, string][]
            ).map(([name, cubic, desc]) => (
              <div key={name} className="el-press rounded-2xl bg-bg2 px-3 py-2">
                <div className="flex items-center justify-between">
                  <span className="font-display text-[13px] font-bold text-ink">
                    {name}
                  </span>
                  <span className="mono text-[10px] text-teal">{cubic}</span>
                </div>
                <p className="mt-0.5 text-[11px] text-dim">{desc}</p>
              </div>
            ))}
          </div>
        </Panel>

        <Panel label="Tap feedback">
          <div className="flex flex-wrap gap-3">
            <RippleButton>Press me</RippleButton>
            <RippleButton variant="secondary">Save</RippleButton>
            <RippleButton variant="premium">Premium</RippleButton>
          </div>
          <p className="mt-3 text-[12px] text-dim">
            Every press radiates a teal ring — visible in under 200ms.
          </p>
        </Panel>

        <Panel label="Reward sequence">
          <RewardStack />
        </Panel>
      </div>
    </Section>
  );
}

function FxTile({
  name,
  desc,
  Icon,
  tone,
}: {
  name: string;
  desc: string;
  Icon: typeof IconBolt;
  tone: "teal" | "pink" | "amber" | "lime" | "down";
}) {
  return (
    <div className="el-press group rounded-2xl border border-line/70 bg-bg2 p-3">
      <div className="flex items-center gap-2">
        <span
          className={`flex h-8 w-8 items-center justify-center rounded-xl el-1 ${
            tone === "teal"  ? "bg-teal/15 text-teal" :
            tone === "pink"  ? "bg-pink/15 text-pink" :
            tone === "amber" ? "bg-amber/15 text-amber" :
            tone === "lime"  ? "bg-lime/15 text-lime" :
                               "bg-down/15 text-down"
          }`}
        >
          <Icon size={15} />
        </span>
        <span className="mono text-[11px] font-bold text-ink">{name}</span>
      </div>
      <p className="mt-2 text-[11px] text-dim">{desc}</p>
      <div className="mt-2 h-1 rounded-full bg-line/50">
        <div
          className={`h-full rounded-full bg-gradient-to-r ${
            tone === "teal"  ? "from-teal to-wait" :
            tone === "pink"  ? "from-pink to-amber" :
            tone === "amber" ? "from-amber to-pink" :
            tone === "lime"  ? "from-lime to-up" :
                               "from-down to-amber"
          }`}
          style={{
            width: `${60 + Math.random() * 30}%`,
          }}
        />
      </div>
    </div>
  );
}

function RippleButton({
  children,
  variant = "primary",
}: {
  children: React.ReactNode;
  variant?: "primary" | "secondary" | "premium";
}) {
  const [ripples, setRipples] = useState<{ x: number; y: number; k: number }[]>([]);
  return (
    <button
      onClick={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        const k = Date.now();
        setRipples((p) => [...p, { x: e.clientX - r.left, y: e.clientY - r.top, k }]);
        setTimeout(() => setRipples((p) => p.filter((x) => x.k !== k)), 700);
      }}
      className={`pressable focus-ring font-display relative h-12 overflow-hidden rounded-2xl px-6 text-[13.5px] font-bold ${
        variant === "primary"
          ? "el-glow bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f]"
          : variant === "premium"
            ? "el-glow-pink bg-gradient-to-r from-pink to-amber text-[#2a0716]"
            : "el-2 border border-line bg-gradient-to-b from-card to-surface text-ink"
      }`}
    >
      {ripples.map((r) => (
        <span
          key={r.k}
          className="absolute h-2 w-2 rounded-full bg-white/60"
          style={{
            left: r.x - 4,
            top: r.y - 4,
            animation: "ripple 0.7s var(--ease-out-expo) forwards",
          }}
        />
      ))}
      {children}
    </button>
  );
}

function RewardStack() {
  const [trig, setTrig] = useState(0);
  return (
    <div className="relative flex h-[180px] items-center justify-center">
      <button
        onClick={() => setTrig((v) => v + 1)}
        className="pressable focus-ring font-display el-glow rounded-2xl bg-gradient-to-b from-[#63f6de] to-teal px-5 py-3 text-[13px] font-bold text-[#04241f]"
      >
        Win level
      </button>
      {trig > 0 && (
        <>
          <span
            key={`c${trig}`}
            className="absolute inset-0 m-auto h-40 w-40 rounded-full"
            style={{
              background: "radial-gradient(circle, rgba(46,230,200,.45) 0%, transparent 70%)",
              animation: "burst 0.8s ease forwards",
            }}
          />
          <span
            key={`xp${trig}`}
            className="xp-rise pointer-events-none absolute font-display text-[24px] font-black text-lime"
            style={{ top: "20%" }}
          >
            +250 XP
          </span>
          {Array.from({ length: 14 }).map((_, i) => {
            const angle = (i / 14) * Math.PI * 2;
            const r = 90 + Math.random() * 60;
            const tx = Math.cos(angle) * r;
            const ty = Math.sin(angle) * r - 30;
            const colors = ["#2ee6c8", "#f0a64d", "#ff4d94", "#50c890", "#b7f739", "#5aa9ff"];
            return (
              <span
                key={`p${trig}-${i}`}
                className="absolute"
                style={{
                  left: "50%",
                  top: "50%",
                  width: 8,
                  height: 14,
                  borderRadius: 2,
                  background: colors[i % colors.length],
                  boxShadow: `0 0 10px ${colors[i % colors.length]}`,
                  ["--tx" as string]: `${tx}px`,
                  ["--ty" as string]: `${ty}px`,
                  animation: `confettiPop 0.3s ease forwards, confetti 1.3s ${i * 25}ms ease forwards`,
                }}
              />
            );
          })}
        </>
      )}
    </div>
  );
}

/* ============ Level-complete card ============ */
function LevelCompleteCard() {
  return (
    <div
      className="el-3 relative w-[260px] overflow-hidden rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-5"
      style={{ animation: "springIn 0.7s cubic-bezier(.34, 1.56, .64, 1) forwards" }}
    >
      <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-teal/30 blur-2xl" />
      <span className="el-glow relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f]">
        <IconCheck size={26} />
      </span>
      <p className="font-display relative mt-3 text-[20px] font-bold text-ink">
        Level 8 complete!
      </p>
      <p className="relative mt-1 text-[12px] text-dim">
        You unstake and re-stake correctly.
      </p>

      <div className="relative mt-3 flex items-center gap-3">
        <span className="el-1 rounded-full bg-lime/15 px-3 py-1 text-[11px] font-black text-lime">
          +250 XP
        </span>
        <span className="mono text-[10px] text-dim">13 / 24 lessons</span>
      </div>

      <div className="relative mt-3">
        <ProgressBar value={62} />
      </div>

      <button className="pressable focus-ring font-display relative mt-4 h-11 w-full rounded-2xl bg-gradient-to-b from-[#63f6de] to-teal text-[13.5px] font-bold text-[#04241f] el-glow">
        Next level →
      </button>

      <div className="xp-rise pointer-events-none absolute right-3 top-3 rounded-full bg-gradient-to-b from-amber to-pink px-3 py-1 text-[11px] font-black text-[#0a1120]">
        +50 XP
      </div>
    </div>
  );
}

function ProgressBar({ value }: { value: number }) {
  return (
    <div className="el-press h-2.5 w-full overflow-hidden rounded-full bg-bg2">
      <div
        className="h-full rounded-full bg-gradient-to-r from-teal to-wait shadow-[0_0_18px_rgba(46,230,200,.55)]"
        style={{ animation: `grow 0.8s var(--ease-out-expo) forwards`, width: `${value}%` }}
      />
    </div>
  );
}


