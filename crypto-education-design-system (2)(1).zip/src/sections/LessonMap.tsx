import { useState } from "react";
import { Section, Panel, Chip, Progress, Ring, Code } from "../components/ui";
import { IconBook, IconCheck, IconClock, IconArrow, IconBolt } from "../components/Icons";
import { LESSONS, QUIZ_QUESTIONS } from "../data";

export function LessonMap() {
  const [active, setActive] = useState(0);
  const lvl = LESSONS[active];

  const done = lvl.items.filter((i) => i.done).length;
  const total = lvl.items.length;
  const pct = Math.round((done / total) * 100);

  return (
    <Section
      id="lessons"
      index="06c"
      eyebrow="Lesson map"
      icon={<IconBook size={17} />}
      title="Curriculum as a graph"
      desc="Beginner · Intermediate · Advanced. Switch tracks, track completion and dive into a quiz."
    >
      <div className="el-3 grid gap-4 rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-5 lg:grid-cols-[260px_1fr]">
        {/* Sidebar */}
        <div className="space-y-2">
          {LESSONS.map((l, i) => {
            const d = l.items.filter((x) => x.done).length;
            const t = l.items.length;
            const p = Math.round((d / t) * 100);
            return (
              <button
                key={l.key}
                onClick={() => setActive(i)}
                className={`el-press w-full rounded-2xl border p-3 text-left transition-all ${
                  i === active
                    ? "border-teal/50 bg-teal/10"
                    : "border-line/70 bg-card hover:border-teal/30"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-[13px] font-bold text-ink">
                    {l.title}
                  </span>
                  <span className="mono text-[10px] text-dim">
                    {d}/{t}
                  </span>
                </div>
                <div className="mt-2">
                  <Progress value={p} height={5} tone={p === 100 ? "lime" : "teal"} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Active track */}
        <div>
          <div className="flex items-end justify-between gap-3">
            <div>
              <span className="mono text-[10px] uppercase tracking-widest text-teal">
                track · {lvl.title.toLowerCase()}
              </span>
              <h3 className="font-display mt-1 text-[20px] font-bold text-ink">
                {done} of {total} complete
              </h3>
            </div>
            <Ring value={pct} size={68} stroke={7} />
          </div>

          <div className="mt-4 space-y-2">
            {lvl.items.map((it) => (
              <div
                key={it.id}
                className={`el-press flex items-center gap-3 rounded-2xl border px-3 py-3 transition-colors ${
                  it.current
                    ? "border-teal/40 bg-teal/10"
                    : "border-line/70 bg-card"
                }`}
              >
                <span
                  className={`flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-bold ${
                    it.done
                      ? "bg-up text-[#04241f]"
                      : it.current
                        ? "bg-teal text-[#04241f]"
                        : "border border-line text-dim"
                  }`}
                >
                  {it.done ? <IconCheck size={12} /> : it.current ? "→" : "•"}
                </span>
                <div className="flex-1">
                  <p className="font-display text-[13px] font-bold text-ink">
                    {it.title}
                  </p>
                  <p className="mono text-[10px] text-dim">{it.mins} min · quiz</p>
                </div>
                <IconClock size={13} className="text-dim" />
                <IconArrow size={14} className="text-teal" />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel label="Sample quiz">
          <QuizSample />
        </Panel>
        <Panel label="Spec">
          <Code lang="ts">{`// data/lessons.ts
export const LESSONS = [
  { key: "beginner", title: "Beginner", items: [
    { id: "wallet",   title: "Wallets 101",  mins: 9,  done: true  },
    { id: "keys",     title: "Public keys",  mins: 7,  done: true  },
    // ...
  ]},
  // ...
];

<LessonMap /> // interactive overview`}</Code>
        </Panel>
      </div>
    </Section>
  );
}

function QuizSample() {
  const q = QUIZ_QUESTIONS[0];
  const [picked, setPicked] = useState<number | null>(null);
  return (
    <div className="space-y-3">
      <Chip tone="wait">{q.topic}</Chip>
      <p className="font-display text-[16px] font-bold leading-snug text-ink">
        {q.q}
      </p>
      <div className="space-y-2">
        {q.options.map((o, i) => {
          const state =
            picked === null
              ? "idle"
              : o.correct
                ? "correct"
                : picked === i
                  ? "wrong"
                  : "idle";
          return (
            <button
              key={o.k}
              onClick={() => setPicked(i)}
              className={`el-press w-full rounded-2xl border px-4 py-2.5 text-left text-[12.5px] font-semibold transition-colors ${
                state === "correct"
                  ? "border-up/50 bg-up/15 text-up"
                  : state === "wrong"
                    ? "border-down/40 bg-down/10 text-down"
                    : "border-line/70 bg-card text-ink"
              }`}
            >
              <span className="mono mr-2 text-[10px] text-dim">{o.k}</span>
              {o.t}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <div className="el-2 mt-2 flex items-center gap-2 rounded-2xl border border-up/30 bg-up/[0.08] p-3 text-[11.5px] text-up">
          <IconBolt size={14} /> {q.explain}
        </div>
      )}
    </div>
  );
}
