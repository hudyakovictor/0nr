import { useState } from "react";
import { Section, Panel, Code, Ring } from "../components/ui";
import { IconPalette, IconCheck } from "../components/Icons";

type ThemeKey = "dark" | "dim" | "midnight" | "dusk";

const THEMES: Record<ThemeKey, {
  bg: string;
  bg2: string;
  surface: string;
  card: string;
  line: string;
  ink: string;
  dim: string;
  teal: string;
  preview: string;
  note: string;
}> = {
  dark: {
    bg: "#070c14",
    bg2: "#0a1120",
    surface: "#0e1a30",
    card: "#13243f",
    line: "#1d3866",
    ink: "#e8eef7",
    dim: "#8aa7c9",
    teal: "#2ee6c8",
    preview:
      "linear-gradient(160deg,#13243f 0%,#0e1a30 50%,#070c14 100%)",
    note: "Default. The brand. Maximum brand teal pop.",
  },
  dim: {
    bg: "#0c1320",
    bg2: "#10182a",
    surface: "#15243d",
    card: "#1a2d4c",
    line: "#284777",
    ink: "#f0f4fc",
    dim: "#9cb3d4",
    teal: "#3ff0d2",
    preview:
      "linear-gradient(160deg,#1a2d4c 0%,#15243d 50%,#0c1320 100%)",
    note: "Lower contrast, easier on the eyes for long sessions.",
  },
  midnight: {
    bg: "#020409",
    bg2: "#05080f",
    surface: "#080d18",
    card: "#0d1424",
    line: "#18243d",
    ink: "#e6ecf6",
    dim: "#7c93b8",
    teal: "#2ee6c8",
    preview:
      "linear-gradient(160deg,#0d1424 0%,#080d18 50%,#020409 100%)",
    note: "AMOLED — true black, saves battery on OLED devices.",
  },
  dusk: {
    bg: "#0c1024",
    bg2: "#121734",
    surface: "#1a2148",
    card: "#212c5c",
    line: "#324478",
    ink: "#f2f0ff",
    dim: "#a3acd6",
    teal: "#9bf4d6",
    preview:
      "linear-gradient(160deg,#212c5c 0%,#1a2148 50%,#0c1024 100%)",
    note: "Indigo tint — pairs with pink premium tones.",
  },
};

const STEPS = [
  ["01", "Tokens",        "Theme is a flat object of CSS variables."],
  ["02", "Provider",      "Wrap the app in <ThemeProvider theme=\"…\">."],
  ["03", "Hook",          "useTheme() returns name + setter for live switching."],
  ["04", "Tokens export", "JSON + CSS + Figma styles all generated."],
];

export function Theming() {
  const [t, setT] = useState<ThemeKey>("dark");
  const theme = THEMES[t];

  return (
    <Section
      id="theming"
      index="14"
      eyebrow="Theming"
      icon={<IconPalette size={17} />}
      title="One system, four surfaces"
      desc="Swap the entire palette by changing seven tokens. No component hardcodes a color — ever."
    >
      <div className="grid gap-4 lg:grid-cols-[260px_1fr]">
        <div className="space-y-2">
          {(Object.keys(THEMES) as ThemeKey[]).map((k) => {
            const th = THEMES[k];
            return (
              <button
                key={k}
                onClick={() => setT(k)}
                className={`el-press w-full rounded-2xl border p-3 text-left transition-all ${
                  t === k ? "border-teal/50 bg-teal/8" : "border-line/70 bg-card hover:border-teal/30"
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className="el-2 h-12 w-12 shrink-0 rounded-2xl border border-white/10"
                    style={{ background: th.preview }}
                  />
                  <div className="flex-1">
                    <p className="font-display text-[14px] font-bold capitalize text-ink">
                      {k}
                    </p>
                    <p className="text-[10.5px] text-dim">{th.note}</p>
                  </div>
                  {t === k && <IconCheck size={16} className="text-teal" />}
                </div>
              </button>
            );
          })}
        </div>

        <div className="space-y-4">
          {/* Live preview phone */}
          <div className="el-3 relative overflow-hidden rounded-3xl border border-line/70 p-5" style={{ background: theme.bg }}>
            <div className="absolute inset-0 grid-dots opacity-40" />
            <div className="relative grid gap-4 md:grid-cols-2">
              <div
                className="rounded-3xl border p-4"
                style={{ background: theme.card, borderColor: theme.line }}
              >
                <div className="flex items-center justify-between">
                  <span
                    className="mono text-[10px] uppercase tracking-widest"
                    style={{ color: theme.teal }}
                  >
                    theme · {t}
                  </span>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                    style={{
                      background: `${theme.teal}22`,
                      color: theme.teal,
                    }}
                  >
                    live
                  </span>
                </div>
                <p
                  className="font-display mt-2 text-[24px] font-bold leading-tight"
                  style={{ color: theme.ink }}
                >
                  Crypto education,
                  <br />
                  <span style={{ color: theme.teal }}>engineered to teach.</span>
                </p>
                <p
                  className="mt-2 text-[12.5px] leading-relaxed"
                  style={{ color: theme.dim }}
                >
                  Live preview. Click any swatch to inspect the token.
                </p>
                <div className="mt-4 flex gap-2">
                  <button
                    className="rounded-2xl px-4 py-2.5 text-[12px] font-bold"
                    style={{
                      background: `linear-gradient(180deg, ${theme.teal}, ${theme.teal}cc)`,
                      color: theme.bg,
                      boxShadow: `0 1px 0 rgba(255,255,255,.4) inset, 0 10px 22px -8px ${theme.teal}aa`,
                    }}
                  >
                    Primary
                  </button>
                  <button
                    className="rounded-2xl border px-4 py-2.5 text-[12px] font-bold"
                    style={{
                      background: theme.card,
                      borderColor: theme.line,
                      color: theme.ink,
                    }}
                  >
                    Secondary
                  </button>
                </div>
              </div>

              <div
                className="rounded-3xl border p-4"
                style={{ background: theme.surface, borderColor: theme.line }}
              >
                <p
                  className="mono text-[10px] uppercase tracking-widest"
                  style={{ color: theme.teal }}
                >
                  chart
                </p>
                <p
                  className="font-display mt-2 text-[20px] font-bold tabular-nums"
                  style={{ color: theme.ink }}
                >
                  $68,412<span style={{ color: theme.teal }}>.30</span>
                </p>
                <p
                  className="text-[11.5px] font-semibold"
                  style={{ color: "#50c890" }}
                >
                  +2.41% · 24h
                </p>
                <svg viewBox="0 0 240 60" className="mt-3 h-16 w-full">
                  <path
                    d="M0 50 L30 40 L60 44 L90 28 L120 30 L150 14 L180 22 L210 8 L240 12 L240 60 L0 60Z"
                    fill={theme.teal}
                    fillOpacity="0.18"
                  />
                  <path
                    d="M0 50 L30 40 L60 44 L90 28 L120 30 L150 14 L180 22 L210 8 L240 12"
                    stroke={theme.teal}
                    strokeWidth="2.4"
                    fill="none"
                  />
                </svg>
                <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                  {[
                    ["Risk", "low"],
                    ["APR", "14.6%"],
                    ["Lock", "21d"],
                  ].map(([k, v]) => (
                    <div
                      key={k}
                      className="rounded-xl px-2 py-1.5"
                      style={{ background: theme.bg2 }}
                    >
                      <p
                        className="mono text-[9px] uppercase tracking-widest"
                        style={{ color: theme.dim }}
                      >
                        {k}
                      </p>
                      <p
                        className="mt-1 font-mono text-[11px] font-bold"
                        style={{ color: theme.ink }}
                      >
                        {v}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <Panel label="Token map">
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {(Object.entries(theme) as [keyof typeof theme, string][])
                .filter(([k]) => !["preview", "note"].includes(k))
                .map(([k, v]) => (
                  <div
                    key={k}
                    className="el-press rounded-xl bg-bg2 p-3"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="h-6 w-6 rounded-lg border border-white/10"
                        style={{ background: v }}
                      />
                      <span className="mono text-[10px] uppercase text-dim">{k}</span>
                    </div>
                    <p className="mono mt-2 text-[11.5px] font-bold text-ink">{v}</p>
                  </div>
                ))}
            </div>
          </Panel>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <Panel label="How theming works">
          <div className="grid gap-3 sm:grid-cols-2">
            {STEPS.map(([n, t, d]) => (
              <div
                key={n}
                className="el-press flex items-start gap-3 rounded-2xl bg-bg2 p-3"
              >
                <span className="font-display text-[18px] font-bold text-teal">
                  {n}
                </span>
                <div>
                  <p className="font-display text-[13px] font-bold text-ink">{t}</p>
                  <p className="mt-1 text-[11.5px] text-dim">{d}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <Code lang="ts">{`import { ThemeProvider, useTheme } from "@signal-arena/react";

<ThemeProvider theme="midnight">
  <App />
</ThemeProvider>;

const { theme, setTheme } = useTheme();
setTheme("dusk"); // swap the whole surface`}</Code>
          </div>
        </Panel>

        <Panel label="Theme checklist">
          <ul className="space-y-2 text-[12.5px]">
            {[
              "Contrast audit still AAA on every pair",
              "Iconography unchanged across themes",
              "Number widths stay tabular",
              "Glow remains readable on dark variants",
              "Brand teal hue ≥ brand-spec limit",
              "Background luminance ≤ 80/255",
            ].map((c) => (
              <li key={c} className="flex items-center gap-2 text-dim">
                <span className="el-1 flex h-5 w-5 items-center justify-center rounded-full bg-up/15 text-up">
                  <IconCheck size={11} />
                </span>
                {c}
              </li>
            ))}
          </ul>
          <div className="el-press mt-4 rounded-2xl bg-bg2 p-3">
            <div className="flex items-center gap-3">
              <Ring value={94} size={56} stroke={6} />
              <div>
                <p className="mono text-[10px] uppercase tracking-widest text-dim">
                  Audit
                </p>
                <p className="font-display text-[14px] font-bold text-ink">
                  9.4 / 10 · 120 factors
                </p>
              </div>
            </div>
          </div>
        </Panel>
      </div>
    </Section>
  );
}
