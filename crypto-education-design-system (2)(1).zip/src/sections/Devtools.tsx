import { useState } from "react";
import { Section, Panel, Code, Chip, Button, Progress, Ring } from "../components/ui";
import {
  IconBolt,
  IconArrow,
  IconCheck,
  IconLayers,
  IconChart,
  IconClock,
  IconFlame,
  IconGrid,
} from "../components/Icons";

/* ============== Interactive playground ============== */
type Variant = "primary" | "secondary" | "outline" | "danger" | "premium" | "ghost";
type Size = "sm" | "md" | "lg";
type Tone =
  | "teal"
  | "wait"
  | "amber"
  | "pink"
  | "up"
  | "down"
  | "lime"
  | "dim";

const VARIANT_LABELS: Variant[] = ["primary", "secondary", "outline", "danger", "premium", "ghost"];
const SIZE_LABELS: Size[] = ["sm", "md", "lg"];
const TONE_LABELS: Tone[] = ["teal", "wait", "amber", "pink", "up", "down", "lime", "dim"];

const VARIANT_DESCRIPTIONS: Record<Variant, string> = {
  primary:   "Solid teal action with brand glow",
  secondary: "Hairline outline for routine actions",
  outline:   "Translucent teal surface, soft border",
  danger:    "Destructive or irreversible action",
  premium:   "Paid tier — pink → amber gradient",
  ghost:     "Quiet hover-only treatment",
};

export function Devtools() {
  const [variant, setVariant] = useState<Variant>("primary");
  const [size, setSize] = useState<Size>("md");
  const [tone, setTone] = useState<Tone>("teal");
  const [iconPos, setIconPos] = useState<"left" | "right" | "none">("left");
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [progress, setProgress] = useState(56);
  const [ringVal, setRingVal] = useState(72);

  return (
    <Section
      id="playground"
      index="15"
      eyebrow="Playground"
      icon={<IconBolt size={17} />}
      title="The whole system, live"
      desc="Click any token. Drag any slider. The system responds instantly — the code on the right stays in sync."
    >
      <div className="el-3 grid gap-4 rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-5 lg:grid-cols-[1fr_360px]">
        {/* Live preview */}
        <div className="el-press grid min-h-[440px] place-items-center rounded-3xl bg-bg2/80 p-6 grid-dots">
          <div className="flex flex-col items-center gap-6">
            <Button
              variant={variant}
              size={size}
              loading={loading}
              disabled={disabled}
              icon={iconPos === "left" ? <IconBolt size={16} /> : undefined}
              iconRight={iconPos === "right" ? <IconArrow size={16} /> : undefined}
            >
              Start lesson
            </Button>

            <div className="flex items-center gap-6">
              <Ring value={ringVal} size={92} stroke={9} label="ring" />
              <Progress
                value={progress}
                tone={tone === "up" || tone === "down" || tone === "wait" || tone === "dim" ? "teal" : (tone as "teal" | "amber" | "lime" | "pink")}
                height={10}
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Chip tone={tone as "teal"} icon={<IconCheck size={12} />}>
                {tone}
              </Chip>
              <Chip tone="dim" icon={<IconClock size={12} />}>6 min</Chip>
              <Chip tone="amber" icon={<IconFlame size={12} />}>+50 XP</Chip>
            </div>

            <p className="text-[12px] text-dim">{VARIANT_DESCRIPTIONS[variant]}</p>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-4">
          <Control label="variant">
            <div className="flex flex-wrap gap-2">
              {VARIANT_LABELS.map((v) => (
                <Chip
                  key={v}
                  tone={v === variant ? "teal" : "dim"}
                  active={v === variant}
                  onClick={() => setVariant(v)}
                >
                  {v}
                </Chip>
              ))}
            </div>
          </Control>

          <Control label="size">
            <div className="flex flex-wrap gap-2">
              {SIZE_LABELS.map((s) => (
                <Chip
                  key={s}
                  tone={s === size ? "teal" : "dim"}
                  active={s === size}
                  onClick={() => setSize(s)}
                >
                  {s}
                </Chip>
              ))}
            </div>
          </Control>

          <Control label="tone">
            <div className="flex flex-wrap gap-2">
              {TONE_LABELS.map((t) => (
                <Chip
                  key={t}
                  tone={t === tone ? "teal" : "dim"}
                  active={t === tone}
                  onClick={() => setTone(t)}
                >
                  {t}
                </Chip>
              ))}
            </div>
          </Control>

          <Control label="icon">
            <div className="flex flex-wrap gap-2">
              {(["left", "right", "none"] as const).map((p) => (
                <Chip
                  key={p}
                  tone={p === iconPos ? "teal" : "dim"}
                  active={p === iconPos}
                  onClick={() => setIconPos(p)}
                >
                  {p}
                </Chip>
              ))}
            </div>
          </Control>

          <Control label="states">
            <div className="flex flex-wrap gap-2">
              <Chip
                tone={loading ? "amber" : "dim"}
                active={loading}
                onClick={() => setLoading((v) => !v)}
              >
                loading
              </Chip>
              <Chip
                tone={disabled ? "down" : "dim"}
                active={disabled}
                onClick={() => setDisabled((v) => !v)}
              >
                disabled
              </Chip>
            </div>
          </Control>

          <Control label="progress">
            <input
              type="range"
              min={0}
              max={100}
              value={progress}
              onChange={(e) => setProgress(+e.target.value)}
              className="el-press h-2 w-full cursor-pointer appearance-none rounded-full bg-bg2"
              style={{ accentColor: "#2ee6c8" }}
            />
            <p className="mono mt-1 text-[10.5px] text-dim">{progress}%</p>
          </Control>

          <Control label="ring">
            <input
              type="range"
              min={0}
              max={100}
              value={ringVal}
              onChange={(e) => setRingVal(+e.target.value)}
              className="el-press h-2 w-full cursor-pointer appearance-none rounded-full bg-bg2"
              style={{ accentColor: "#2ee6c8" }}
            />
            <p className="mono mt-1 text-[10.5px] text-dim">{ringVal}%</p>
          </Control>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel label="Generated JSX">
          <Code lang="tsx">{`<Button
  variant="${variant}"
  size="${size}"${loading ? "\n  loading" : ""}${disabled ? "\n  disabled" : ""}
${iconPos === "left"   ? "  icon={<IconBolt size={16} />}" : ""}${iconPos === "right" ? "  iconRight={<IconArrow size={16} />}" : ""}
>
  Start lesson
</Button>

<Progress value={${progress}} tone="${tone}" />
<Ring value={${ringVal}} size={92} label="ring" />
<Chip tone="${tone}" icon={<IconCheck size={12} />}>${tone}</Chip>`}</Code>
        </Panel>

        <Panel label="Generated tokens">
          <Code lang="css">{`/* derived from current playground state */
--accent:        var(--${tone});
--progress:      ${progress}%;
--ring:          ${ringVal}%;
--button-height: var(--btn-${size === "sm" ? "sm" : size === "lg" ? "lg" : "md"});`}</Code>
        </Panel>
      </div>
    </Section>
  );
}

function Control({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mono mb-2 text-[10px] uppercase tracking-[0.22em] text-dim">
        {label}
      </p>
      {children}
    </div>
  );
}

/* ============== Handoff page ============== */
export function Handoff() {
  const [tab, setTab] = useState<"tokens" | "icons" | "favicon" | "figma">("tokens");

  return (
    <Section
      id="handoff"
      index="16"
      eyebrow="Handoff"
      icon={<IconLayers size={17} />}
      title="Engineer-ready"
      desc="Tokens as JSON, icons as a sprite, a 32px favicon and a Figma library skeleton. Drop straight into any project."
    >
      <div className="mb-4 flex flex-wrap gap-2">
        {(["tokens", "icons", "favicon", "figma"] as const).map((k) => (
          <Chip
            key={k}
            tone={tab === k ? "teal" : "dim"}
            active={tab === k}
            onClick={() => setTab(k)}
          >
            {k}
          </Chip>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
        <Panel label={tab.toUpperCase()}>
          {tab === "tokens" && (
            <Code lang="json">{`{
  "color": {
    "bg":      "#070c14",
    "bg2":     "#0a1120",
    "surface": "#0e1a30",
    "card":    "#13243f",
    "line":    "#1d3866",
    "dim":     "#8aa7c9",
    "ink":     "#e8eef7",
    "teal":    "#2ee6c8",
    "up":      "#50c890",
    "down":    "#eb635b",
    "wait":    "#5aa9ff",
    "amber":   "#f0a64d",
    "lime":    "#b7f739",
    "pink":    "#ff4d94"
  },
  "radius":  { "card": 24, "control": 16, "sheet": 32, "device": 46 },
  "shadow":  ["el-1","el-2","el-3","el-4","el-glow"],
  "motion":  { "fast": 180, "base": 280, "slow": 420,
               "ease": "cubic-bezier(.22,1,.36,1)" }
}`}</Code>
          )}
          {tab === "icons" && (
            <Code lang="svg">{`<!-- sprite.svg — drop into /public/icons -->
<svg xmlns="http://www.w3.org/2000/svg" style="display:none">
  <symbol id="i-shield" viewBox="0 0 24 24" fill="none" stroke="currentColor"
          stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
    <path d="M12 3l7 3v5.5c0 4.6-3 8-7 9.5-4-1.5-7-4.9-7-9.5V6z"/>
    <path d="m9 12 2 2 4-4"/>
  </symbol>
  <symbol id="i-cube" viewBox="0 0 24 24" fill="none" stroke="currentColor"
          stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
    <path d="m12 2.8 8 4.4v9.6l-8 4.4-8-4.4V7.2z"/>
    <path d="M12 12.2 20 7.6M12 12.2v9M12 12.2 4 7.6"/>
  </symbol>
  <!-- 26 icons total -->
</svg>

<!-- usage -->
<svg class="h-5 w-5 text-teal"><use href="/icons/sprite.svg#i-shield"/></svg>`}</Code>
          )}
          {tab === "favicon" && (
            <Code lang="html">{`<!-- /public/favicon.svg — auto-themed -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#63f6de"/>
      <stop offset="100%" stop-color="#2ee6c8"/>
    </linearGradient>
  </defs>
  <rect width="32" height="32" rx="8" fill="#0e1a30"/>
  <ellipse cx="16" cy="16" rx="11" ry="5" stroke="url(#g)"
    stroke-width="2.5" stroke-linecap="round"
    transform="rotate(-22 16 16)"/>
  <circle cx="16" cy="16" r="4.2" fill="url(#g)"/>
</svg>

<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icon-180.png">`}</Code>
          )}
          {tab === "figma" && (
            <Code lang="ts">{`// figma plugin — Variables
{ name: "color/bg",      type: "COLOR", value: "#070c14" }
{ name: "color/teal",    type: "COLOR", value: "#2ee6c8" }
{ name: "color/ink",     type: "COLOR", value: "#e8eef7" }
{ name: "radius/card",   type: "FLOAT", value: 24 }
{ name: "radius/sheet",  type: "FLOAT", value: 32 }
{ name: "space/4",       type: "FLOAT", value: 16 }
{ name: "space/6",       type: "FLOAT", value: 24 }
{ name: "elevation/l1",  type: "EFFECT", value: { ... } }
{ name: "elevation/l2",  type: "EFFECT", value: { ... } }
{ name: "elevation/l3",  type: "EFFECT", value: { ... } }
{ name: "motion/base",   type: "FLOAT", value: 280 }

// 52 components, 4 themes, 1 source of truth`}</Code>
          )}
        </Panel>

        <Panel label="What's exported">
          <ul className="space-y-2 text-[12.5px]">
            {[
              ["tokens.json",  "All design tokens as JSON"],
              ["tokens.css",   "Generated CSS variables"],
              ["icons.svg",    "Sprite with 26 symbols"],
              ["favicon.svg",  "Brand-mark favicon, auto-themed"],
              ["figma.json",   "Variables and effect styles"],
              ["logos.zip",    "Logo in 3 versions + 4 plates"],
              ["audit.pdf",    "120-factor scoring sheet"],
              ["react/",       "@signal-arena/react package"],
            ].map(([n, d]) => (
              <li
                key={n}
                className="el-press flex items-center justify-between rounded-2xl bg-bg2 px-3 py-2"
              >
                <span className="mono text-[12px] font-bold text-teal">{n}</span>
                <span className="text-[11.5px] text-dim">{d}</span>
              </li>
            ))}
          </ul>
          <div className="el-press mt-4 rounded-2xl border border-up/30 bg-up/[0.07] p-4">
            <div className="flex items-center gap-3">
              <span className="el-1 flex h-9 w-9 items-center justify-center rounded-xl bg-up/15 text-up">
                <IconCheck size={15} />
              </span>
              <div>
                <p className="font-display text-[13.5px] font-bold text-up">
                  Engineer-ready
                </p>
                <p className="text-[11.5px] text-dim">
                  Zero hardcoded colors. Every component subscribes to tokens.
                </p>
              </div>
            </div>
          </div>
        </Panel>
      </div>
    </Section>
  );
}

/* ============== Roadmap page ============== */
type Item = {
  q: string;
  title: string;
  desc: string;
  state: "Backlog" | "Design" | "Build" | "QA" | "Shipped";
  tag: "Engine" | "Edu" | "Market" | "Wallet" | "AI";
  effort: 1 | 2 | 3;
};

const QUARTERS = [
  {
    q: "Q2 2026",
    items: [
      ["DeFi 2.0 track",       "5 lessons on restaking & intent", "Edu",     "Build",   2],
      ["Local currency view",  "USD/EUR/JPY toggle on portfolio", "Market",  "Design",  1],
      ["Push notification v2", "Per-coin alerts, smart digest",   "Engine",  "Shipped", 3],
    ] as [string, string, Item["tag"], Item["state"], Item["effort"]][],
  },
  {
    q: "Q3 2026",
    items: [
      ["AI tutor",             "GPT-style explainer in app",      "AI",      "Design",  3],
      ["Cross-chain swap",     "Bridge UI inside the wallet",     "Wallet",  "Backlog", 3],
      ["Social feed",          "Follow traders, copy settings",   "Edu",     "Backlog", 2],
    ] as [string, string, Item["tag"], Item["state"], Item["effort"]][],
  },
];

const TAG_COLORS: Record<Item["tag"], string> = {
  Engine: "wait",
  Edu: "teal",
  Market: "amber",
  Wallet: "pink",
  AI: "lime",
};

const STATE_COLORS: Record<Item["state"], string> = {
  Backlog: "dim",
  Design:  "amber",
  Build:   "wait",
  QA:      "pink",
  Shipped: "up",
};

export function Roadmap() {
  return (
    <Section
      id="roadmap"
      index="17"
      eyebrow="Roadmap"
      icon={<IconChart size={17} />}
      title="Six months, twenty things"
      desc="Every quarter we ship a new wave. Items are tagged, sized and visibly tracked from backlog to shipped."
    >
      <div className="grid gap-4 lg:grid-cols-2">
        {QUARTERS.map((q, qi) => (
          <Panel
            key={q.q}
            label={q.q}
            className="space-y-3"
          >
            {q.items.map(([title, desc, tag, state, effort]) => (
              <div
                key={title}
                className="el-press rounded-2xl bg-bg2 p-4"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <Chip tone={TAG_COLORS[tag] as "teal"}>{tag}</Chip>
                  <Chip tone={STATE_COLORS[state] as "teal"}>{state}</Chip>
                  <span className="mono text-[10px] text-dim">
                    effort · {"●".repeat(effort) + "○".repeat(3 - effort)}
                  </span>
                </div>
                <p className="font-display mt-3 text-[15px] font-bold text-ink">
                  {title}
                </p>
                <p className="mt-1 text-[12px] text-dim">{desc}</p>
              </div>
            ))}
            <div className="mt-2 flex items-center justify-between text-[10.5px] text-dim">
              <span>Quarter {qi + 1} of 2026</span>
              <span className="mono">{q.items.length} items</span>
            </div>
          </Panel>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-4">
        {(
          [
            ["Backlog", 4],
            ["Design",  2],
            ["Build",   1],
            ["QA",      0],
            ["Shipped", 3],
          ] as [string, number][]
        ).map(([k, n]) => (
          <div
            key={k}
            className="el-2 rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-4"
          >
            <p className="mono text-[10px] uppercase tracking-widest text-teal">{k}</p>
            <p className="font-display mt-1 text-[28px] font-bold text-ink tabular-nums">
              {n}
            </p>
            <p className="text-[11px] text-dim">
              {k === "Backlog" && "things being groomed"}
              {k === "Design" && "specs being drawn up"}
              {k === "Build" && "engineers working"}
              {k === "QA" && "polishing for ship"}
              {k === "Shipped" && "released this quarter"}
            </p>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ============== Index of every page on the site ============== */
export function Sitemap() {
  const sections = [
    ["Foundations",  "foundations", "01",  "Grid, radius, motion, density"],
    ["Color",        "color",      "02",  "Tokens, semantic, contrast"],
    ["Type",         "type",       "03",  "Display, body, mono"],
    ["Logo",         "logo",       "04",  "Brand mark, plates, rules"],
    ["Elevation",    "elevation",  "05",  "Five tiers + shadow tuner"],
    ["Icons",        "icons",      "06",  "26 line icons"],
    ["Library",      "index",      "06b", "52 components catalog"],
    ["Curriculum",   "lessons",    "06c", "Lesson map"],
    ["Skill cards",  "skill",      "06d", "White-glyph colored plates"],
    ["Components",   "components", "07",  "Playground + state matrix"],
    ["Motion",       "motion",     "08",  "Easing, durations, loaders"],
    ["Patterns",     "patterns",   "09",  "Lesson card, streak, feed"],
    ["Pages",        "pages",      "10",  "Onboarding, paywall, search"],
    ["Screens",      "screens",    "11",  "Live app previews"],
    ["Audit",        "audit",      "12",  "120-factor scoring"],
    ["Brand",        "brand",      "13",  "Voice & tone rules"],
    ["Changelog",    "changelog",  "14",  "Release timeline"],
    ["Theming",      "theming",    "15",  "Four surface presets"],
    ["Playground",   "playground", "16",  "Live design tokens playground"],
    ["Handoff",      "handoff",    "17",  "Tokens, sprite, favicon"],
    ["Roadmap",      "roadmap",    "18",  "Six months ahead"],
  ] as [string, string, string, string][];

  return (
    <Section
      id="sitemap"
      index="19"
      eyebrow="Sitemap"
      icon={<IconGrid size={17} />}
      title="Every page, every section"
      desc="Twenty-one sections, all anchored. Press G then / to jump to any of them from the command palette."
    >
      <Panel className="!p-0">
        <div className="grid grid-cols-[auto_1fr_auto_2fr] gap-x-4 px-5 py-3 mono text-[10px] uppercase tracking-widest text-dim">
          <span>#</span>
          <span>section</span>
          <span>id</span>
          <span>scope</span>
        </div>
        {sections.map(([n, id, idx, d], i) => (
          <a
            key={id}
            href={`#${id}`}
            className={`grid grid-cols-[auto_1fr_auto_2fr] items-center gap-x-4 px-5 py-3 text-[13px] transition-colors hover:bg-teal/[0.06] ${
              i % 2 ? "bg-card/30" : "bg-card/55"
            }`}
          >
            <span className="mono text-[10px] text-dim">{idx}</span>
            <span className="font-display font-bold text-ink">{n}</span>
            <span className="mono text-[11px] text-teal">#{id}</span>
            <span className="text-[11.5px] text-dim">{d}</span>
          </a>
        ))}
      </Panel>
    </Section>
  );
}
