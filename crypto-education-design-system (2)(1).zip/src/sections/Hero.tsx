import { Phone, PhoneApp, TABS } from "../components/Phone";
import {
  Button,
  Chip,
  Counter,
  Stat,
} from "../components/ui";
import { LogoGlyph, IconBolt, IconArrow } from "../components/Icons";
import { MARQUEE } from "../data";

export function Hero() {
  return (
    <div id="top" className="relative overflow-hidden noise">
      <div className="pointer-events-none absolute inset-0">
        <div className="aurora absolute -left-40 -top-40 h-[520px] w-[520px] rounded-full bg-teal/25" />
        <div className="aurora absolute -right-32 top-10 h-[460px] w-[460px] rounded-full bg-wait/20 [animation-delay:-6s]" />
        <div className="aurora absolute bottom-0 left-1/3 h-[420px] w-[420px] rounded-full bg-pink/12 [animation-delay:-12s]" />
      </div>
      <div className="absolute inset-0 grid-lines" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 pb-16 pt-14 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:pb-24 lg:pt-20">
        <div>
          <Chip tone="teal" icon={<LogoGlyph size={13} orbit="#2ee6c8" planet="#2ee6c8" />}>
            Signal Arena DS · 2026
          </Chip>
          <h1 className="font-display mt-6 text-[46px] font-bold leading-[0.98] tracking-[-0.03em] sm:text-[72px]">
            <span className="text-grad">Signal</span>
            <span className="text-ink"> Arena</span>
            <br />
            <span className="text-dim">crypto education,</span>
            <br />
            <span className="text-dim">engineered to teach.</span>
          </h1>
          <p className="mt-6 max-w-xl text-[16px] leading-relaxed text-dim">
            A deep-navy, teal-charged mobile system for financial literacy. 14 semantic
            tokens, a five-tier tactile elevation ladder, one brand glyph in three
            versions, 26 line icons and 52 production components — audited against
            120 design factors.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" icon={<IconBolt size={18} />}>
              Explore the system
            </Button>
            <Button size="lg" variant="secondary" iconRight={<IconArrow size={17} />}>
              Read guidelines
            </Button>
          </div>
          <div className="mt-10 grid max-w-xl grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat value={<Counter to={9.4} decimals={1} />} label="Design score" />
            <Stat value={<Counter to={120} />} label="Audited factors" />
            <Stat value={<Counter to={52} />} label="Components" />
            <Stat value="3" label="Logo versions" />
          </div>
        </div>

        <div className="relative flex flex-col items-center gap-5">
          <HeroCarousel />
        </div>
      </div>

      <div className="relative border-y border-line/50 bg-bg2/60 py-3">
        <div className="marquee flex w-max gap-10 whitespace-nowrap">
          {[...Array(2)].map((_, k) => (
            <div key={k} className="flex gap-10">
              {MARQUEE.map((t) => (
                <span
                  key={t}
                  className="mono flex items-center gap-2.5 text-[11.5px] uppercase tracking-[0.18em] text-dim"
                >
                  <span className="h-1 w-1 rounded-full bg-teal" />
                  {t}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function HeroCarousel() {
  return (
    <>
      <div className="floaty">
        <Phone caption="Tap the tab bar">
          <PhoneApp tab={0} onTab={() => {}} />
        </Phone>
      </div>
      <div className="flex gap-1.5">
        {TABS.map((s, k) => (
          <button
            key={s.key}
            aria-label={s.label}
            className={`h-1.5 rounded-full transition-all duration-500 ${
              k === 0
                ? "w-8 bg-teal shadow-[0_0_10px_rgba(46,230,200,.9)]"
                : "w-3 bg-line"
            }`}
          />
        ))}
      </div>
    </>
  );
}
