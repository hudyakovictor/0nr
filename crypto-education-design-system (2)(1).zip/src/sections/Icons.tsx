import { Section, Panel } from "../components/ui";
import {
  IconHome,
  IconBook,
  IconChart,
  IconUser,
  IconBell,
  IconBolt,
  IconShield,
  IconWave,
  IconCube,
  IconSpark,
  IconSearch,
  IconFlame,
  IconTrophy,
  IconLock,
  IconGift,
  IconClock,
  IconLayers,
  IconGrid,
  IconType,
  IconWallet,
  IconSend,
  IconStar,
  IconArrow,
  IconCheck,
} from "../components/Icons";

const ICONS = [
  ["home",    IconHome],
  ["book",    IconBook],
  ["chart",   IconChart],
  ["user",    IconUser],
  ["bell",    IconBell],
  ["bolt",    IconBolt],
  ["shield",  IconShield],
  ["wave",    IconWave],
  ["cube",    IconCube],
  ["spark",   IconSpark],
  ["search",  IconSearch],
  ["flame",   IconFlame],
  ["trophy",  IconTrophy],
  ["lock",    IconLock],
  ["gift",    IconGift],
  ["clock",   IconClock],
  ["layers",  IconLayers],
  ["grid",    IconGrid],
  ["type",    IconType],
  ["wallet",  IconWallet],
  ["send",    IconSend],
  ["star",    IconStar],
  ["arrow",   IconArrow],
  ["check",   IconCheck],
] as const;

export function Icons() {
  return (
    <Section
      id="icons"
      index="06"
      eyebrow="Iconography"
      icon={<IconSpark size={17} />}
      title="One stroke, one system"
      desc="24×24 grid, 1.8px stroke, round caps and joins. Optically balanced at 16, 20 and 24 — never filled, never mixed with emoji."
    >
      <Panel className="!p-5">
        <div className="grid grid-cols-4 gap-3 sm:grid-cols-6 lg:grid-cols-12">
          {ICONS.map(([n, I]) => (
            <div
              key={n}
              className="el-1 group flex aspect-square flex-col items-center justify-center gap-1.5 rounded-2xl border border-line/60 bg-bg2 text-dim transition-all duration-300 hover:-translate-y-1 hover:border-teal/50 hover:bg-teal/10 hover:text-teal"
            >
              <I size={20} />
              <span className="mono text-[8.5px] opacity-60">{n}</span>
            </div>
          ))}
        </div>
      </Panel>

      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        <Panel label="Sizes">
          <div className="flex items-end justify-around text-teal">
            {[16, 20, 24, 32].map((s) => (
              <div key={s} className="flex flex-col items-center gap-2">
                <IconShield size={s} />
                <span className="mono text-[10px] text-dim">{s}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel label="Containers">
          <div className="flex items-center justify-around">
            <span className="el-1 flex h-11 w-11 items-center justify-center rounded-xl bg-teal/12 text-teal">
              <IconBolt size={19} />
            </span>
            <span className="el-2 flex h-11 w-11 items-center justify-center rounded-2xl border border-line bg-card text-dim">
              <IconBell size={19} />
            </span>
            <span className="el-glow flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f]">
              <IconCheck size={19} />
            </span>
            <span className="el-1 flex h-11 w-11 items-center justify-center rounded-full bg-pink/12 text-pink">
              <IconGift size={19} />
            </span>
          </div>
        </Panel>
        <Panel label="Rules">
          <ul className="space-y-1.5 text-[12.5px] text-dim">
            <li>· White glyph on colored plates for skill cards</li>
            <li>· Stroke never scales below 1.5px</li>
            <li>· Semantic color only, never gradients</li>
            <li>· Paired with an 8px label gap</li>
            <li>· Glyph count: 24 (skill) + 1 brand = 25 total</li>
          </ul>
        </Panel>
      </div>
    </Section>
  );
}
