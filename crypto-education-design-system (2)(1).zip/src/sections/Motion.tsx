import { Section, Panel, Code } from "../components/ui";
import { IconMotion } from "../components/Icons";
import { DURATIONS, EASE } from "../tokens";

export function Motion() {
  return (
    <Section
      id="motion"
      index="08"
      eyebrow="Motion"
      icon={<IconMotion size={17} />}
      title="Movement with intent"
      desc="Four durations, one easing family. Motion confirms cause and effect — it never decorates. Everything collapses gracefully under prefers-reduced-motion."
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Panel label="Easing curve">
          <svg viewBox="0 0 200 80" className="h-24 w-full">
            <path d="M0 76 H200" stroke="#1d3866" strokeWidth="1" />
            <path d="M0 76 C 56 76, 62 6, 198 6" fill="none" stroke="#2ee6c8" strokeWidth="2.6" />
            <circle cx="198" cy="6" r="3.5" fill="#2ee6c8" />
          </svg>
          <p className="mono mt-2 text-[11px] text-dim">{EASE.outExpo}</p>
        </Panel>

        <Panel label="Durations">
          <div className="space-y-2.5">
            {(
              [
                ["micro", DURATIONS.micro, "toggle, chip"],
                ["fast",  DURATIONS.fast,  "press, hover"],
                ["base",  DURATIONS.base,  "cards, tabs"],
                ["slow",  DURATIONS.slow,  "sheets, routes"],
              ] as [string, number, string][]
            ).map(([n, t, u]) => (
              <div
                key={n}
                className="el-press flex items-center justify-between rounded-xl bg-bg2 px-3 py-2 text-[12px]"
              >
                <span className="text-ink">{n}</span>
                <span className="mono text-teal">{t}ms</span>
                <span className="text-dim">{u}</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel label="Live loaders">
          <div className="space-y-3">
            <div className="shimmer h-10 rounded-2xl" />
            <div className="flex items-center gap-3">
              <span className="h-8 w-8 animate-spin rounded-full border-2 border-teal/25 border-t-teal" />
              <span className="pulse-ring h-8 w-8 rounded-full bg-teal/20" />
              <div className="flex gap-1.5">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className="h-2.5 w-2.5 animate-bounce rounded-full bg-teal"
                    style={{ animationDelay: `${i * 140}ms` }}
                  />
                ))}
              </div>
            </div>
            <div className="shimmer h-3 rounded-full" />
          </div>
        </Panel>

        <Panel label="Transition path">
          <svg viewBox="0 0 200 90" className="h-24 w-full">
            <rect x="6" y="30" width="46" height="34" rx="9" fill="#13243f" stroke="#1d3866" />
            <rect x="148" y="18" width="46" height="58" rx="12" fill="#0f3a37" stroke="#2ee6c8" />
            <path d="M56 47 C 100 47, 104 42, 144 42" stroke="#2ee6c8" strokeWidth="2" className="dash" fill="none" />
          </svg>
          <p className="mt-1 text-[12px] text-dim">
            Shared-element card → detail, {DURATIONS.slow}ms.
          </p>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel label="Press feedback">
          <div className="grid grid-cols-2 gap-3">
            <button className="pressable el-2 flex h-20 flex-col items-center justify-center rounded-2xl border border-line bg-gradient-to-b from-card to-surface font-display text-[13px] font-semibold text-ink">
              Default
            </button>
            <button className="pressable el-2 flex h-20 flex-col items-center justify-center rounded-2xl border border-teal/40 bg-gradient-to-b from-card to-surface font-display text-[13px] font-semibold text-teal">
              Hover
            </button>
            <button className="el-press flex h-20 flex-col items-center justify-center rounded-2xl border border-line bg-gradient-to-b from-card to-surface font-display text-[13px] font-semibold text-ink">
              Pressed
            </button>
            <button className="el-ring flex h-20 flex-col items-center justify-center rounded-2xl border border-teal/60 bg-gradient-to-b from-card to-surface font-display text-[13px] font-semibold text-ink">
              Focused
            </button>
          </div>
        </Panel>

        <Panel label="Reduced-motion fallback">
          <Code lang="css">{`@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.001ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.001ms !important;
  }
  .reveal { opacity: 1; }
}`}</Code>
          <p className="mono mt-3 text-[10.5px] leading-relaxed text-dim">
            Tailwind ships with `motion-safe:` and `motion-reduce:` modifiers —
            we always pair them on looped animations.
          </p>
        </Panel>
      </div>
    </Section>
  );
}
