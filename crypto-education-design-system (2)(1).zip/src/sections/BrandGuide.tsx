import { Section, Panel, Chip, Code } from "../components/ui";
import {
  IconSpark,
  IconArrow,
  IconBolt,
  IconCheck,
  IconX,
} from "../components/Icons";
import { Button } from "../components/ui";

const DO = [
  ["Use teal on navy", "Clear contrast, brand-true"],
  ["Layer elevation", "el-1 → el-2 → el-3 by importance"],
  ["Hold 44pt targets", "iOS / Android comfort zone"],
  ["Tabular numbers", "Money never wiggles on screen"],
  ["State every button", "hover, press, focus, loading"],
  ["Mind the thumb", "Actions go bottom-right"],
];

const DONT = [
  ["Recolor the glyph", "Only 3 approved versions"],
  ["Use gradients on glyph", "Keep the mark flat"],
  ["Mix emoji and icons", "Pick one icon family"],
  ["Use red/green for status", "Use up/down tones"],
  ["Animate without reason", "Motion confirms cause"],
  ["Hide focus rings", "Focus is a feature"],
];

export function BrandGuide() {
  return (
    <Section
      id="brand"
      index="12"
      eyebrow="Brand guide"
      icon={<IconSpark size={17} />}
      title="Voice, tone and rules"
      desc="A 30-second style reference. Use the do/don't grid as a checklist when shipping anything new."
    >
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel label="Voice">
          <p className="font-display text-[22px] font-bold leading-tight text-ink">
            Calm. Sharp. Patient.
          </p>
          <p className="mt-3 text-[13px] leading-relaxed text-dim">
            We teach crypto like a friend who happens to know a lot of finance.
            Short sentences, plain English, never condescending. We celebrate progress
            without hyping risk.
          </p>
          <div className="el-press mt-4 rounded-2xl bg-bg2 p-4">
            <p className="mono text-[10px] uppercase tracking-widest text-dim">
              example · good
            </p>
            <p className="mt-2 text-[13.5px] text-ink">
              "Validators stake capital — dishonest behavior gets slashed."
            </p>
          </div>
          <div className="el-press mt-3 rounded-2xl bg-bg2 p-4 opacity-70">
            <p className="mono text-[10px] uppercase tracking-widest text-down">
              example · bad
            </p>
            <p className="mt-2 text-[13.5px] text-dim">
              "OMG! PoS is basically magic that prints money! 🚀🚀🚀"
            </p>
          </div>
        </Panel>

        <Panel label="Do" tone="teal">
          <ul className="space-y-2">
            {DO.map(([t, d]) => (
              <li
                key={t}
                className="el-press flex items-start gap-3 rounded-2xl bg-bg2 p-3"
              >
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-up/15 text-up">
                  <IconCheck size={12} />
                </span>
                <div>
                  <p className="font-display text-[13px] font-bold text-ink">{t}</p>
                  <p className="text-[11.5px] text-dim">{d}</p>
                </div>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel label="Don't">
          <ul className="space-y-2">
            {DONT.map(([t, d]) => (
              <li
                key={t}
                className="el-press flex items-start gap-3 rounded-2xl bg-bg2 p-3"
              >
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-down/15 text-down">
                  <IconX size={12} />
                </span>
                <div>
                  <p className="font-display text-[13px] font-bold text-down">{t}</p>
                  <p className="text-[11.5px] text-dim">{d}</p>
                </div>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel label="Editorial sample">
          <div className="el-2 rounded-2xl border border-line/70 bg-card p-5">
            <Chip tone="teal">Beginner · 6 min read</Chip>
            <h3 className="font-display mt-3 text-[22px] font-bold leading-tight text-ink">
              What is a wallet, really?
            </h3>
            <p className="mt-3 text-[13.5px] leading-relaxed text-dim">
              A wallet doesn't hold your coins. It holds the private keys that prove
              you control an address on a blockchain. Think of it as a keychain, not a
              piggy bank. Lose the keys, lose access — there's no hotline to call.
            </p>
            <p className="mt-3 text-[13.5px] leading-relaxed text-dim">
              In the next lesson we'll set up a hot wallet, fund it with test ETH
              and watch a real transaction settle on-chain.
            </p>
            <div className="mt-5 flex gap-2">
              <Button size="sm" variant="secondary" icon={<IconArrow size={14} />}>
                Read full article
              </Button>
              <Button size="sm" icon={<IconBolt size={14} />}>
                Start lesson
              </Button>
            </div>
          </div>
        </Panel>

        <Panel label="Code snippet">
          <Code lang="tsx">{`import { Button, Chip, Progress } from "@signal-arena/react";

export function LessonCard({ title, mins, pct }) {
  return (
    <div className="el-2 rounded-3xl border border-line bg-card p-4">
      <Chip tone="teal">{mins} min</Chip>
      <h3 className="font-display mt-3 text-lg font-bold text-ink">
        {title}
      </h3>
      <Progress value={pct} className="mt-3" />
      <Button className="mt-4" full>Continue</Button>
    </div>
  );
}`}</Code>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {(
          [
            ["Tone", "Calm & patient"],
            ["Reading", "Grade 8"],
            ["Sentence", "≤ 14 words"],
            ["Emoji", "Never on icon"],
          ] as [string, string][]
        ).map(([k, v]) => (
          <div
            key={k}
            className="el-2 rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-5"
          >
            <p className="mono text-[10px] uppercase tracking-widest text-teal">{k}</p>
            <p className="font-display mt-2 text-[20px] font-bold text-ink">{v}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}
