import { Section, Panel } from "../components/ui";
import { IconType } from "../components/Icons";
import { TYPE_SCALE } from "../tokens";

export function Typography() {
  return (
    <Section
      id="type"
      index="03"
      eyebrow="Typography"
      icon={<IconType size={17} />}
      title="Space Grotesk × Inter × JetBrains Mono"
      desc="Geometric display for headings and numerals, a neutral grotesque for dense educational prose, monospace for addresses, hashes and token values."
    >
      <div className="grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <Panel label="Type scale">
          <div className="space-y-5">
            {TYPE_SCALE.map((row) => (
              <div
                key={row.token}
                className="border-b border-line/50 pb-4 last:border-0 last:pb-0"
              >
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="mono text-[10px] uppercase tracking-[0.22em] text-teal">
                    {row.token}
                  </span>
                  <span className="mono text-[10.5px] text-dim">{row.spec}</span>
                </div>
                <SampleText row={row} />
              </div>
            ))}
          </div>
        </Panel>
        <div className="space-y-4">
          <Panel label="Live numerics" tone="teal">
            <p className="font-display text-[46px] font-bold leading-none tabular-nums text-ink">
              $68,412<span className="text-teal">.30</span>
            </p>
            <p className="mono mt-2 text-[13px] font-semibold text-up">+2.41% · 24h</p>
            <p className="mt-4 text-[13px] leading-relaxed text-dim">
              Tabular lining figures keep market columns stable while prices tick live —
              widths never shift.
            </p>
          </Panel>
          <Panel label="Text tones">
            <div className="space-y-2">
              {[
                ["Primary — ink", "text-ink"],
                ["Secondary — dim", "text-dim"],
                ["Accent — teal", "text-teal"],
                ["Disabled — line", "text-line"],
              ].map(([t, c]) => (
                <p key={t} className={`text-[15px] ${c}`}>
                  {t}
                </p>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </Section>
  );
}

function SampleText({ row }: { row: (typeof TYPE_SCALE)[number] }) {
  const samples: Record<string, string> = {
    display: "Learn crypto",
    h1:      "Blockchain basics",
    h2:      "What is a wallet?",
    h3:      "Confirm transaction",
    body:    "A wallet stores the private keys that prove ownership of your assets on-chain.",
    caption: "Updated 2 hours ago",
    mono:    "0x8f2a…c41d",
  };
  const cls =
    row.family === "display"
      ? "font-display font-bold"
      : row.family === "mono"
        ? "mono"
        : "font-sans";
  return (
    <p
      className={`leading-tight text-ink ${cls}`}
      style={{ fontSize: row.size, lineHeight: `${row.line}px`, fontWeight: row.weight }}
    >
      {samples[row.token]}
    </p>
  );
}
