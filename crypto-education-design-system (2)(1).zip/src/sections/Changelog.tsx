import { useState } from "react";
import { Section, Panel, Chip, Reveal } from "../components/ui";
import {
  IconSpark,
  IconBolt,
  IconShield,
  IconCube,
  IconWave,
  IconLayers,
  IconStar,
  IconArrow,
  IconCheck,
  IconChart,
  IconWallet,
  IconGift,
  IconLock,
  IconFlame,
  IconClock,
  IconTrophy,
} from "../components/Icons";

type Release = {
  ver: string;
  date: string;
  channel: "Major" | "Minor" | "Patch";
  status: "Shipped" | "Beta" | "In review";
  notes: string[];
  highlights: { I: typeof IconSpark; t: string; body: string }[];
};

const RELEASES: Release[] = [
  {
    ver: "2.7.0",
    date: "Mar 2026",
    channel: "Major",
    status: "Shipped",
    notes: [
      "Skill card overhaul with white-glyph colored plates",
      "Live ticker on Market — 1.7s polling window",
      "Lesson map with three tracks and quiz feedback",
      "Topbar: floating capsule with ⌘K palette",
    ],
    highlights: [
      { I: IconStar,   t: "Skill cards", body: "6 tracks with progress, difficulty, XP, tags." },
      { I: IconBolt,   t: "Live data",   body: "Market & Wallet tick live every 1.7 seconds." },
      { I: IconLayers, t: "Topbar",      body: "Pill nav, glass surface, ⌘K command palette." },
    ],
  },
  {
    ver: "2.6.0",
    date: "Feb 2026",
    channel: "Minor",
    status: "Shipped",
    notes: [
      "Brand mark simplified to one glyph in three versions",
      "Five-tier elevation ladder with inner highlight + ambient spread",
      "Shadow tuner playground with live CSS export",
      "Accent theming — switch teal / wait / lime / pink",
    ],
    highlights: [
      { I: IconCube,   t: "Brand mark",    body: "Single orbit glyph, three official versions." },
      { I: IconShield, t: "Elevation",     body: "5 levels with shadow tuner & generated CSS." },
      { I: IconSpark,  t: "Theming",       body: "Five accent tokens, zero hardcoded colors." },
    ],
  },
  {
    ver: "2.5.0",
    date: "Jan 2026",
    channel: "Minor",
    status: "Shipped",
    notes: [
      "Tabular numerics on every market data view",
      "AAA contrast audit across 14 tokens",
      "JetBrains Mono added for addresses and hashes",
      "Reduced-motion fallback hard-coded into root CSS",
    ],
    highlights: [
      { I: IconChart, t: "Tabular nums", body: "Money stops wiggling as values update." },
      { I: IconCheck, t: "AAA audit",    body: "5/5 critical pairs pass WCAG AAA contrast." },
      { I: IconLock,  t: "a11y",         body: "prefers-reduced-motion honored globally." },
    ],
  },
  {
    ver: "2.4.0",
    date: "Dec 2025",
    channel: "Minor",
    status: "Beta",
    notes: [
      "Wallet screen — Send/Receive with live fee estimate",
      "Achievements grid with locked/unlocked states",
      "Staking position card with APR and unbonding",
      "Onboarding three-step flow with progress dots",
    ],
    highlights: [
      { I: IconWallet, t: "Wallet",       body: "Send / Receive / fee estimate / seed prompt." },
      { I: IconTrophy, t: "Achievements", body: "8 badges with locked + unlocked states." },
      { I: IconFlame,  t: "Onboarding",   body: "Three steps, skip option, persistent dots." },
    ],
  },
  {
    ver: "2.3.0",
    date: "Nov 2025",
    channel: "Patch",
    status: "Shipped",
    notes: [
      "Token table export as TypeScript constant",
      "Reveal-on-scroll animation with 70ms stagger",
      "Toast & snackbar with auto-dismiss",
      "Bottom sheet with drag handle and stepper",
    ],
    highlights: [
      { I: IconArrow, t: "Reveal", body: "IntersectionObserver-powered fade-up." },
      { I: IconClock, t: "Toasts", body: "Self-dismiss, queued, reveals on top." },
    ],
  },
  {
    ver: "2.2.0",
    date: "Oct 2025",
    channel: "Patch",
    status: "Shipped",
    notes: [
      "Glass surface utility — backdrop blur 18px",
      "Aurora gradients in hero",
      "Marquee token strip",
      "Skeletons for loading rows",
    ],
    highlights: [
      { I: IconSpark, t: "Glass",    body: "0.82 surface + 18px blur + saturation." },
      { I: IconGift,  t: "Marquee",  body: "Token strip animations on key sections." },
    ],
  },
];

const CHANNELS: ("All" | "Major" | "Minor" | "Patch")[] = [
  "All",
  "Major",
  "Minor",
  "Patch",
];

export function Changelog() {
  const [filter, setFilter] = useState<(typeof CHANNELS)[number]>("All");
  const list = RELEASES.filter((r) => filter === "All" || r.channel === filter);

  return (
    <Section
      id="changelog"
      index="13"
      eyebrow="Changelog"
      icon={<IconWave size={17} />}
      title="What's shipped, what's next"
      desc="Six releases, twelve highlights. Every change is auditable; every decision is documented."
    >
      <div className="mb-5 flex flex-wrap gap-2">
        {CHANNELS.map((c) => (
          <Chip
            key={c}
            tone={filter === c ? "teal" : "dim"}
            active={filter === c}
            onClick={() => setFilter(c)}
          >
            {c}
          </Chip>
        ))}
      </div>

      <div className="relative">
        {/* timeline rail */}
        <div className="absolute left-[19px] top-3 bottom-3 hidden w-px bg-gradient-to-b from-teal via-wait to-pink md:block" />

        <div className="space-y-4">
          {list.map((r, i) => (
            <Reveal key={r.ver} delay={i * 60}>
              <ReleaseRow release={r} />
            </Reveal>
          ))}
        </div>
      </div>
    </Section>
  );
}

function ReleaseRow({ release }: { release: Release }) {
  const tone = release.channel === "Major" ? "teal" : release.channel === "Minor" ? "wait" : "dim";
  const statusTone =
    release.status === "Shipped" ? "up" : release.status === "Beta" ? "amber" : "down";
  return (
    <div className="relative flex gap-4">
      {/* timeline dot */}
      <div className="relative z-10 hidden md:block">
        <span className="el-glow flex h-10 w-10 items-center justify-center rounded-full bg-card">
          <span className="h-2.5 w-2.5 rounded-full bg-teal shadow-[0_0_12px_rgba(46,230,200,.9)]" />
        </span>
      </div>

      <Panel className="flex-1">
        <div className="flex flex-wrap items-center gap-3">
          <Chip tone={tone}>{release.channel}</Chip>
          <Chip tone={statusTone}>{release.status}</Chip>
          <span className="font-display text-[15px] font-bold text-ink">
            v{release.ver}
          </span>
          <span className="mono text-[10.5px] text-dim">{release.date}</span>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {release.highlights.map((h, i) => {
            const I = h.I;
            return (
              <div
                key={i}
                className="el-press rounded-2xl bg-bg2 p-3"
              >
                <div className="flex items-center gap-2">
                  <span className="el-1 flex h-7 w-7 items-center justify-center rounded-lg bg-teal/12 text-teal">
                    <I size={13} />
                  </span>
                  <p className="font-display text-[12.5px] font-bold text-ink">{h.t}</p>
                </div>
                <p className="mt-2 text-[11.5px] leading-relaxed text-dim">{h.body}</p>
              </div>
            );
          })}
        </div>

        <ul className="mt-4 space-y-1.5">
          {release.notes.map((n) => (
            <li key={n} className="flex items-start gap-2 text-[12px] text-dim">
              <span className="mt-1.5 h-1 w-1 rounded-full bg-teal" />
              {n}
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
