import { Button } from "../components/ui";
import { IconBolt, IconArrow, LogoWordmark } from "../components/Icons";

export function Footer() {
  return (
    <footer className="relative mt-10 overflow-hidden border-t border-line/50 noise">
      <div className="pointer-events-none absolute inset-0">
        <div className="aurora absolute -bottom-40 left-1/4 h-[420px] w-[420px] rounded-full bg-teal/16" />
      </div>
      <div className="relative mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <LogoWordmark size={44} />
            <p className="mt-4 max-w-md text-[13.5px] leading-relaxed text-dim">
              2026 Edition · 14 tokens · 1 brand glyph in 3 versions · 26 icons ·
              52 components · 5 elevation tiers. Built dark-first for people learning
              money on a small screen.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button icon={<IconBolt size={17} />}>Download kit</Button>
            <Button variant="secondary" iconRight={<IconArrow size={16} />}>
              Documentation
            </Button>
          </div>
        </div>
        <div className="mt-12 flex flex-col gap-3 border-t border-line/50 pt-6 text-[12px] text-dim sm:flex-row sm:items-center sm:justify-between">
          <span className="mono">© 2026 Signal Arena — v2.7.0</span>
          <div className="flex gap-5">
            {["Changelog", "Tokens JSON", "Figma", "GitHub"].map((l) => (
              <a key={l} href="#top" className="transition-colors hover:text-teal">
                {l}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
