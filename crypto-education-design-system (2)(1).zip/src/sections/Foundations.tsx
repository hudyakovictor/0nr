import { Section, Panel, Reveal, Code } from "../components/ui";
import { IconGrid } from "../components/Icons";
import { FOUNDATIONS } from "../data";

export function Foundations() {
  return (
    <Section
      id="foundations"
      index="01"
      eyebrow="Foundations"
      icon={<IconGrid size={17} />}
      title="Rules before pixels"
      desc="Every surface, shadow and interval derives from one tokenized scale — so a card in Home and a sheet in Wallet are mathematically the same object."
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {FOUNDATIONS.map(({ t, s, d }, i) => (
          <Reveal key={t} delay={i * 70}>
            <Panel className="h-full">
              <p className="font-display text-[19px] font-bold text-ink">{t}</p>
              <p className="mono mt-1 text-[12px] font-semibold text-teal">{s}</p>
              <p className="mt-3 text-[13px] leading-relaxed text-dim">{d}</p>
            </Panel>
          </Reveal>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel label="Radius scale">
          <div className="flex items-end gap-3">
            {[12, 16, 24, 32].map((r) => (
              <div key={r} className="flex-1 text-center">
                <div
                  className="el-2 h-16 w-full border border-line bg-gradient-to-b from-card to-surface"
                  style={{ borderRadius: r }}
                />
                <span className="mono mt-1.5 block text-[10px] text-dim">{r}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel label="Spacing ramp">
          <div className="flex items-end gap-2">
            {[4, 8, 12, 16, 24, 32, 48].map((s) => (
              <div key={s} className="flex flex-col items-center gap-1.5">
                <div
                  className="el-1 rounded bg-gradient-to-b from-teal to-teal/50"
                  style={{ width: s, height: 30 }}
                />
                <span className="mono text-[9.5px] text-dim">{s}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel label="Token export">
          <Code>{`--color-teal: #2ee6c8;
--radius-card: 24px;
--space-4: 16px;
--ease-out-expo:
  cubic-bezier(.22,1,.36,1);
--shadow-l2:
  0 1px 0 rgba(255,255,255,.07)
    inset,
  0 2px 6px rgba(2,6,14,.55),
  0 14px 32px -14px #02060e;`}</Code>
        </Panel>
      </div>
    </Section>
  );
}
