import { Section, Panel, Reveal } from "../components/ui";
import {
  LogoGlyph,
  LogoColor,
  LogoTwoTone,
  LogoMono,
  LogoPlate,
  IconX,
  IconCheck,
} from "../components/Icons";

const VERSIONS = [
  {
    n: "01 · Primary / Color",
    d: "Gradient orbit + teal planet on navy plate. App icons, marketing, splash.",
    el: <LogoColor size={104} detail />,
  },
  {
    n: "02 · Two-tone",
    d: "Blue orbit + teal planet on transparent. UI headers, in-app nav.",
    el: <LogoTwoTone size={104} />,
  },
  {
    n: "03 · Mono ink",
    d: "Single ink on any background. Watermarks, print, disabled states.",
    el: <LogoMono size={104} tone="#e8eef7" />,
  },
  {
    n: "03b · Mono navy",
    d: "Single navy on light plates. Documents, invoices, email.",
    el: (
      <div className="el-2 flex h-[104px] w-[104px] items-center justify-center rounded-3xl bg-ink">
        <LogoMono size={66} tone="#0e1a30" />
      </div>
    ),
  },
];

const MISUSES = [
  ["Don't stretch", "Keep 1:1 aspect"],
  ["Don't recolor", "Brand palette only"],
  ["Don't add effects", "No bevels or strokes"],
  ["Don't crowd", "Respect clearspace"],
] as const;

export function Logos() {
  return (
    <Section
      id="logo"
      index="04"
      eyebrow="Logo & App icon"
      icon={<LogoGlyph size={17} orbit="#2ee6c8" planet="#2ee6c8" />}
      title="One glyph, three licensed versions"
      desc="The mark is a simplified signal-orbit: one ring, one body. Nothing else. Choose a version by contrast budget — never redraw, recolor or stretch it."
    >
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {VERSIONS.map((v, i) => (
          <Reveal key={v.n} delay={i * 70}>
            <div className="el-2 relative flex h-full flex-col items-center overflow-hidden rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface p-6">
              <div className="absolute inset-x-0 top-0 h-40 grid-lines opacity-60" />
              <div className="relative flex h-[120px] items-center justify-center">
                {v.el}
              </div>
              <p className="font-display relative mt-5 text-[14px] font-bold text-ink">
                {v.n}
              </p>
              <p className="relative mt-1.5 text-center text-[12px] leading-relaxed text-dim">
                {v.d}
              </p>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel label="App icon family">
          <div className="flex flex-wrap items-end gap-4">
            <div className="text-center">
              <LogoPlate size={92} kind="dark" />
              <p className="mono mt-2 text-[10px] text-dim">iOS / dark</p>
            </div>
            <div className="text-center">
              <LogoPlate size={92} kind="light" />
              <p className="mono mt-2 text-[10px] text-dim">light plate</p>
            </div>
            <div className="text-center">
              <LogoPlate size={72} kind="dark" shape="circle" />
              <p className="mono mt-2 text-[10px] text-dim">adaptive</p>
            </div>
            <div className="text-center">
              <LogoPlate size={72} kind="mono" shape="circle" />
              <p className="mono mt-2 text-[10px] text-dim">notifications</p>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-3 rounded-2xl border border-line/60 bg-bg2 p-3">
            <LogoColor size={40} detail={false} />
            <div>
              <p className="mono text-[10px] text-dim">tray / 16–32px</p>
              <p className="text-[11px] text-ink">
                Ring 2.5px keeps the silhouette readable.
              </p>
            </div>
          </div>
        </Panel>

        <Panel label="Minimum size & clearspace">
          <div className="flex items-end gap-5">
            {[96, 64, 48, 32, 24, 16].map((s) => (
              <div key={s} className="flex flex-col items-center gap-2">
                <LogoColor size={s} radius={s * 0.26} detail={s > 40} />
                <span className="mono text-[9.5px] text-dim">{s}</span>
              </div>
            ))}
          </div>
          <div className="el-press mt-4 rounded-2xl border border-dashed border-teal/50 bg-bg2 p-5">
            <div className="relative flex items-center justify-center">
              <span className="absolute inset-0 rounded-xl border border-dashed border-teal/30" />
              <LogoColor size={64} />
            </div>
            <p className="mono mt-3 text-[10.5px] text-teal">
              clearspace = 0.25 × glyph width (16px at 64px)
            </p>
          </div>
        </Panel>

        <Panel label="Usage rules">
          <div className="grid grid-cols-2 gap-3">
            {MISUSES.map(([t, d]) => (
              <div
                key={t}
                className="el-1 relative overflow-hidden rounded-2xl border border-down/25 bg-bg2 p-3"
              >
                <div className="flex items-center gap-2">
                  <LogoTwoTone size={30} />
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-down/20 text-down">
                    <IconX size={11} />
                  </span>
                </div>
                <p className="font-display mt-2 text-[12px] font-bold text-down">{t}</p>
                <p className="text-[10.5px] text-dim">{d}</p>
                <span className="absolute inset-y-0 left-0 w-full origin-left rotate-[8deg] scale-x-125 border-t border-down/40" />
              </div>
            ))}
          </div>
          <div className="el-1 mt-3 flex items-center gap-2 rounded-2xl border border-up/25 bg-up/[0.07] p-3">
            <IconCheck size={14} className="text-up" />
            <p className="text-[11.5px] text-up">
              Approved backgrounds: bg, bg2, surface, card and any tint ≥ 4.5:1.
            </p>
          </div>
        </Panel>
      </div>
    </Section>
  );
}
