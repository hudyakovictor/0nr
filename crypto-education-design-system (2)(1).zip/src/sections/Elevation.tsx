import { useState } from "react";
import { Section, Panel, Chip, Code } from "../components/ui";
import { IconLayers } from "../components/Icons";
import { DURATIONS } from "../tokens";

export function Elevation() {
  const [level, setLevel] = useState(2);
  const [radius, setRadius] = useState(24);
  const [glow, setGlow] = useState(0);

  const contact = [1, 1, 2, 4, 6, 8][level];
  const blur = [2, 2, 6, 14, 24, 32][level];
  const amb = [4, 10, 32, 64, 110, 140][level];
  const spread = [4, 14, 14, 24, 30, 36][level];
  const inset = 0.05 + level * 0.014;

  const shadow = [
    `inset 0 1px 0 rgba(255,255,255,${inset.toFixed(3)})`,
    `0 ${contact}px ${blur}px rgba(2,6,14,.6)`,
    `0 ${Math.round(amb / 3)}px ${amb}px -${spread}px rgba(0,0,0,.95)`,
    glow > 0
      ? `0 14px 44px -12px rgba(46,230,200,${((glow / 100) * 0.75).toFixed(2)})`
      : null,
  ]
    .filter(Boolean)
    .join(",\n  ");

  const css = `box-shadow:
  ${shadow};
border-radius: ${radius}px;`;

  return (
    <Section
      id="elevation"
      index="05"
      eyebrow="Elevation & Depth"
      icon={<IconLayers size={17} />}
      title="Shadows that feel physical"
      desc="A five-tier ladder: inner top highlight + tight contact shadow + wide ambient spread. Primary actions add a colored key light so the brand literally glows. Tune it live — the CSS is generated for you."
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {(
          [
            ["el-1", "Level 1", "Chips, rows, inline controls"],
            ["el-2", "Level 2", "Cards, sheets, secondary"],
            ["el-3", "Level 3", "Modals, tab bar, popovers"],
            ["el-4", "Level 4", "Full-screen overlays"],
            ["el-glow", "Glow", "Primary action key light"],
          ] as [string, string, string][]
        ).map(([c, t, d], i) => (
          <div
            key={c}
            className="rounded-3xl border border-line/40 bg-bg2/50 p-6 opacity-0 animate-[fadeUp_.6s_var(--ease-out-expo)_forwards]"
            style={{ animationDelay: `${i * 70}ms` }}
          >
            <div
              className={`${c} mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-3xl ${
                c === "el-glow"
                  ? "bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f]"
                  : "border border-line bg-gradient-to-b from-card to-surface text-teal"
              }`}
            >
              <span className="font-display text-[20px] font-bold">{i + 1}</span>
            </div>
            <p className="font-display text-center text-[14.5px] font-bold text-ink">
              {t}
            </p>
            <p className="mt-1 text-center text-[11.5px] leading-relaxed text-dim">
              {d}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1fr]">
        <Panel label="Shadow tuner">
          <div className="grid gap-6 sm:grid-cols-[1fr_220px]">
            <div className="space-y-5">
              {(
                [
                  ["level", level, setLevel, 0, 5, "0"],
                  ["radius", radius, setRadius, 8, 44, "px"],
                  ["glow", glow, setGlow, 0, 100, "%"],
                ] as [string, number, (n: number) => void, number, number, string][]
              ).map(([label, v, set, min, max, unit]) => (
                <div key={label}>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="mono text-[10px] uppercase tracking-[0.22em] text-dim">
                      {label}
                    </span>
                    <span className="mono text-[11px] text-teal">
                      {v}
                      {unit}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={min}
                    max={max}
                    step={label === "level" ? 1 : label === "radius" ? 2 : 5}
                    value={v}
                    onChange={(e) => set(+e.target.value)}
                    className="el-press h-2 w-full cursor-pointer appearance-none rounded-full bg-bg2"
                    style={{ accentColor: "#2ee6c8" }}
                  />
                </div>
              ))}
              <div className="flex flex-wrap gap-2 pt-1">
                {(["el-1", "el-2", "el-3", "el-4", "el-glow"] as const).map(
                  (c, i) => (
                    <Chip
                      key={c}
                      tone={i === level ? "teal" : "dim"}
                      active={i === level}
                      onClick={() => setLevel(i)}
                    >
                      {c}
                    </Chip>
                  ),
                )}
              </div>
            </div>
            <div className="el-press flex items-center justify-center rounded-3xl bg-bg2/70 p-5 grid-lines">
              <div
                className="flex h-[132px] w-full items-center justify-center border border-line bg-gradient-to-b from-card to-surface"
                style={{ boxShadow: shadow, borderRadius: radius }}
              >
                <span className="mono text-[11px] uppercase tracking-widest text-teal">
                  live
                </span>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <Code>{css}</Code>
          </div>
        </Panel>

        <div className="grid gap-4">
          <Panel label="Layer stack">
            <div className="relative h-[190px]">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="el-3 absolute flex items-center justify-center rounded-3xl border border-line bg-gradient-to-br from-card to-surface transition-all duration-500 hover:-translate-y-1"
                  style={{
                    inset: `${i * 26}px ${i * 30}px auto ${i * 30}px`,
                    height: 112,
                    zIndex: i,
                  }}
                >
                  {i === 2 && (
                    <span className="mono text-[11px] uppercase tracking-widest text-teal">
                      focused surface
                    </span>
                  )}
                </div>
              ))}
            </div>
          </Panel>
          <Panel label="Rule of thumb">
            <ul className="space-y-2 text-[12.5px] text-dim">
              <li>· One elevation step per interaction, maximum two per view.</li>
              <li>· Colored glow is reserved for the single primary action.</li>
              <li>· Pressed state always inverts: outer shadow → inner shadow.</li>
              <li>· Levels must stay legible on bg, bg2 and card alike.</li>
              <li>· Default motion: {DURATIONS.base}ms expo-out.</li>
            </ul>
          </Panel>
        </div>
      </div>

      <div className="mt-4">
        <Panel label="Spec card">
          <Code lang="ts">{`// src/tokens/index.ts
export const ELEVATION = {
  1: { className: "el-1", use: "Chips, list rows"        },
  2: { className: "el-2", use: "Cards, sheets"            },
  3: { className: "el-3", use: "Modals, tab bar"          },
  4: { className: "el-4", use: "Full-screen overlays"     },
  glow: { className: "el-glow", use: "Primary action"     },
} as const;`}</Code>
        </Panel>
      </div>
    </Section>
  );
}
