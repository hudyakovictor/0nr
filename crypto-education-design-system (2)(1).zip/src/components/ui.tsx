import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { ELEVATION, COLORS } from "../tokens";
import { IconCopy, IconCheck } from "./Icons";

/* ================= Reveal ================= */
export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => e.isIntersecting && (setSeen(true), io.disconnect()),
      { threshold: 0.12 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={cn("reveal", seen && "in", className)}
      style={{ animationDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

/* ================= Section ================= */
export function Section({
  id,
  index,
  eyebrow,
  title,
  desc,
  icon,
  children,
}: {
  id: string;
  index: string;
  eyebrow: string;
  title: string;
  desc?: string;
  icon?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section
      id={id}
      className="relative mx-auto w-full max-w-7xl scroll-mt-24 px-5 py-14 sm:px-8 sm:py-20"
    >
      <Reveal>
        <div className="mb-10 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <span className="el-1 flex h-9 w-9 items-center justify-center rounded-xl border border-teal/30 bg-teal/10 text-teal">
              {icon}
            </span>
            <span className="mono text-[11px] font-bold uppercase tracking-[0.32em] text-teal">
              {index} — {eyebrow}
            </span>
            <span className="h-px flex-1 bg-gradient-to-r from-line to-transparent" />
          </div>
          <h2 className="font-display max-w-3xl text-[32px] font-bold leading-[1.08] tracking-tight text-ink sm:text-[46px]">
            {title}
          </h2>
          {desc && (
            <p className="max-w-2xl text-[15px] leading-relaxed text-dim">{desc}</p>
          )}
        </div>
      </Reveal>
      {children}
    </section>
  );
}

/* ================= Panel ================= */
export function Panel({
  children,
  className = "",
  label,
  action,
  tone = "default",
}: {
  children: ReactNode;
  className?: string;
  label?: string;
  action?: ReactNode;
  tone?: "default" | "teal" | "flat";
}) {
  const bg =
    tone === "teal"
      ? "from-[#10352f] to-surface border-teal/30"
      : tone === "flat"
        ? "from-bg2 to-bg2 border-line/60"
        : "from-card to-surface border-line/70";
  return (
    <div
      className={cn(
        "el-2 hov-l3 relative overflow-hidden rounded-3xl border bg-gradient-to-b p-5 sm:p-6",
        bg,
        className,
      )}
    >
      {(label || action) && (
        <div className="mb-5 flex items-center justify-between gap-3">
          {label && (
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-teal shadow-[0_0_10px_2px_rgba(46,230,200,0.75)]" />
              <span className="font-display text-[11px] font-semibold uppercase tracking-[0.22em] text-dim">
                {label}
              </span>
            </div>
          )}
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

/* ================= Button ================= */
type Variant = "primary" | "secondary" | "outline" | "ghost" | "danger" | "premium";

const VARIANT_STYLES: Record<Variant, string> = {
  primary:
    "el-glow bg-gradient-to-b from-[#63f6de] to-teal text-[#04241f] hover:brightness-[1.07] hover:-translate-y-[1px]",
  secondary:
    "el-2 border border-line bg-gradient-to-b from-card to-surface text-ink hover:border-teal/55 hover:-translate-y-[1px]",
  outline:
    "el-1 border border-teal/45 bg-teal/[0.06] text-teal hover:bg-teal/[0.14]",
  ghost: "text-dim hover:bg-white/[0.06] hover:text-ink",
  danger:
    "el-2 bg-gradient-to-b from-[#f4796f] to-down text-[#2b0908] shadow-[0_16px_34px_-16px_rgba(235,99,91,0.85)] hover:brightness-105",
  premium:
    "el-glow-pink bg-gradient-to-r from-pink to-amber text-[#2a0716] hover:brightness-105",
};

const SIZE_STYLES: Record<"sm" | "md" | "lg", string> = {
  sm: "h-9 px-4 text-[13px] gap-1.5",
  md: "h-12 px-6 text-[14.5px] gap-2",
  lg: "h-14 px-8 text-[16px] gap-2.5",
};

const RADIUS_STYLES: Record<"xl" | "2xl" | "full", string> = {
  xl: "rounded-xl",
  "2xl": "rounded-2xl",
  full: "rounded-full",
};

export function Button({
  children,
  variant = "primary",
  size = "md",
  icon,
  iconRight,
  full,
  disabled,
  loading,
  onClick,
  radius = "2xl",
}: {
  children?: ReactNode;
  variant?: Variant;
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
  iconRight?: ReactNode;
  full?: boolean;
  disabled?: boolean;
  loading?: boolean;
  onClick?: () => void;
  radius?: "xl" | "2xl" | "full";
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "font-display pressable focus-ring relative inline-flex select-none items-center justify-center overflow-hidden font-semibold transition-all duration-200 ease-[cubic-bezier(.22,1,.36,1)] focus:outline-none active:translate-y-[1px]",
        SIZE_STYLES[size],
        RADIUS_STYLES[radius],
        VARIANT_STYLES[variant],
        full && "w-full",
        disabled && "pointer-events-none opacity-35 grayscale",
      )}
    >
      {loading ? (
        <span className="h-4 w-4 animate-spin rounded-full border-2 border-current/30 border-t-current" />
      ) : (
        icon
      )}
      {children}
      {iconRight}
    </button>
  );
}

/* ================= Chip ================= */
type ChipTone = "teal" | "wait" | "amber" | "pink" | "up" | "down" | "lime" | "dim";

const TONE_STYLES: Record<ChipTone, string> = {
  teal: "text-teal border-teal/40 bg-teal/10",
  wait: "text-wait border-wait/40 bg-wait/10",
  amber: "text-amber border-amber/40 bg-amber/10",
  pink: "text-pink border-pink/40 bg-pink/10",
  up: "text-up border-up/40 bg-up/10",
  down: "text-down border-down/40 bg-down/10",
  lime: "text-lime border-lime/40 bg-lime/10",
  dim: "text-dim border-line bg-card",
};

export function Chip({
  children,
  tone = "teal",
  icon,
  onClick,
  active,
}: {
  children: ReactNode;
  tone?: ChipTone;
  icon?: ReactNode;
  onClick?: () => void;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "el-1 inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] font-semibold transition-all duration-200",
        TONE_STYLES[tone],
        onClick && "hover:-translate-y-[1px]",
        !onClick && "cursor-default",
        active && "ring-1 ring-current",
      )}
    >
      {icon}
      {children}
    </button>
  );
}

/* ================= Progress ================= */
const PROGRESS_GRADIENTS = {
  teal: "from-teal to-wait shadow-[0_0_18px_rgba(46,230,200,0.55)]",
  amber: "from-amber to-pink shadow-[0_0_18px_rgba(240,166,77,0.5)]",
  lime: "from-lime to-up shadow-[0_0_18px_rgba(183,247,57,0.45)]",
  pink: "from-pink to-wait shadow-[0_0_18px_rgba(255,77,148,0.45)]",
} as const;

export function Progress({
  value,
  tone = "teal",
  height = 10,
}: {
  value: number;
  tone?: keyof typeof PROGRESS_GRADIENTS;
  height?: number;
}) {
  return (
    <div
      className="el-press w-full overflow-hidden rounded-full bg-bg2"
      style={{ height }}
    >
      <div
        className={cn(
          "h-full rounded-full bg-gradient-to-r transition-[width] duration-700 ease-[cubic-bezier(.22,1,.36,1)]",
          PROGRESS_GRADIENTS[tone],
        )}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

/* ================= Ring ================= */
export function Ring({
  value,
  size = 92,
  stroke = 9,
  label,
}: {
  value: number;
  size?: number;
  stroke?: number;
  label?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const gradId = `rg${size}`;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#2ee6c8" />
            <stop offset="100%" stopColor="#5aa9ff" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#0a1120" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`url(#${gradId})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={c - (c * value) / 100}
          style={{ transition: "stroke-dashoffset .8s cubic-bezier(.22,1,.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-[17px] font-bold text-ink">{value}%</span>
        {label && (
          <span className="text-[9px] uppercase tracking-widest text-dim">{label}</span>
        )}
      </div>
    </div>
  );
}

/* ================= Swatch ================= */
export function Swatch({ name, hex }: { name: string; hex: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => {
        navigator.clipboard?.writeText(hex);
        setCopied(true);
        setTimeout(() => setCopied(false), 1300);
      }}
      className="group text-left"
    >
      <div
        className="el-2 hov-l4 relative h-[86px] w-full overflow-hidden rounded-2xl border border-white/[0.06] transition-all duration-500 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-translate-y-1.5"
        style={{ background: hex }}
      >
        <span className="absolute inset-0 bg-gradient-to-b from-white/12 to-transparent" />
        <span
          className={cn(
            "absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-lg bg-black/35 text-white backdrop-blur transition-opacity",
            copied ? "opacity-100" : "opacity-0 group-hover:opacity-100",
          )}
        >
          {copied ? <IconCheck size={14} /> : <IconCopy size={14} />}
        </span>
      </div>
      <p className="mt-2 text-[12.5px] font-semibold text-ink">{name}</p>
      <p className="mono text-[11px] text-dim">{copied ? "copied!" : hex}</p>
    </button>
  );
}

/* ================= Tabs ================= */
export function Tabs({
  items,
  value,
  onChange,
}: {
  items: string[];
  value: number;
  onChange: (i: number) => void;
}) {
  return (
    <div className="el-press inline-flex rounded-2xl bg-bg2 p-1">
      {items.map((t, i) => (
        <button
          key={t}
          onClick={() => onChange(i)}
          className={cn(
            "font-display rounded-xl px-4 py-2 text-[13px] font-semibold transition-all duration-300",
            i === value ? "el-2 bg-card text-teal" : "text-dim hover:text-ink",
          )}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

/* ================= Code ================= */
export function Code({ children, lang = "css" }: { children: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="el-press relative rounded-2xl border border-line/70 bg-[#05090f] p-4">
      <button
        onClick={() => {
          navigator.clipboard?.writeText(children);
          setCopied(true);
          setTimeout(() => setCopied(false), 1300);
        }}
        className="absolute right-3 top-3 rounded-lg border border-line bg-card px-2 py-1 text-[10px] font-semibold text-dim transition-colors hover:text-teal"
      >
        {copied ? "copied" : "copy"}
      </button>
      <span className="mono absolute right-16 top-3 text-[10px] uppercase tracking-widest text-dim/60">
        {lang}
      </span>
      <pre className="mono overflow-x-auto text-[12px] leading-relaxed text-dim">
        {children}
      </pre>
    </div>
  );
}

/* ================= Counter (animate on view) ================= */
export function Counter({
  to,
  decimals = 0,
  suffix = "",
  prefix = "",
  duration = 1100,
}: {
  to: number;
  decimals?: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const [v, setV] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        io.disconnect();
        const t0 = performance.now();
        const step = (t: number) => {
          const p = Math.min(1, (t - t0) / duration);
          setV(to * (1 - Math.pow(1 - p, 3)));
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      },
      { threshold: 0.3 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [to, duration]);
  return (
    <span ref={ref} className="tabular-nums">
      {prefix}
      {v.toFixed(decimals)}
      {suffix}
    </span>
  );
}

/* ================= Toast ================= */
export function Toast({
  text,
  onDone,
}: {
  text: string;
  onDone?: () => void;
}) {
  useEffect(() => {
    const t = setTimeout(() => onDone?.(), 2800);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div className="el-3 reveal in flex items-center gap-2.5 rounded-2xl border border-up/40 bg-card p-3 text-[12.5px] text-ink">
      <span className="el-1 flex h-7 w-7 items-center justify-center rounded-lg bg-up/15 text-up">
        <IconCheck size={14} />
      </span>
      {text}
    </div>
  );
}

/* ================= Card primitive (white-on-color skill card) ================= */
export function SkillCard({
  title,
  Icon,
  to,
  plate,
  progress,
}: {
  title: string;
  Icon: typeof IconCopy;
  to: string;
  plate: string;
  progress: number;
}) {
  return (
    <button className="el-2 group rounded-2xl border border-line/70 bg-gradient-to-b from-card to-surface p-3 text-left transition-transform duration-400 hover:-translate-y-0.5">
      <div
        className={cn(
          "el-1 mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br text-white",
          plate,
        )}
      >
        <Icon size={17} />
      </div>
      <p className="font-display text-[12.5px] font-semibold text-ink">{title}</p>
      <p className="mb-2 mono text-[9.5px] text-dim">{to}</p>
      <Progress value={progress} height={5} tone={progress > 70 ? "lime" : "teal"} />
    </button>
  );
}

/* ================= Stat ================= */
export function Stat({
  value,
  label,
  tone = "teal",
}: {
  value: ReactNode;
  label: string;
  tone?: "teal" | "ink";
}) {
  return (
    <div className="el-2 rounded-2xl border border-line/70 bg-gradient-to-b from-card to-surface px-4 py-3 transition-transform duration-500 hover:-translate-y-1">
      <p className={cn("font-display text-[26px] font-bold leading-none", tone === "teal" ? "text-teal" : "text-ink")}>
        {value}
      </p>
      <p className="mt-1.5 text-[11px] text-dim">{label}</p>
    </div>
  );
}

/* ================= Empty state ================= */
export function EmptyState({
  Icon,
  title,
  body,
  cta,
}: {
  Icon: typeof IconCopy;
  title: string;
  body: string;
  cta?: ReactNode;
}) {
  return (
    <div className="el-press flex flex-col items-center gap-3 rounded-2xl border border-dashed border-line bg-bg2 p-5 text-center">
      <span className="el-1 flex h-12 w-12 items-center justify-center rounded-2xl bg-card text-dim">
        <Icon size={20} />
      </span>
      <p className="font-display text-[13px] font-bold text-ink">{title}</p>
      <p className="text-[11.5px] text-dim">{body}</p>
      {cta}
    </div>
  );
}

export { ELEVATION, COLORS };
