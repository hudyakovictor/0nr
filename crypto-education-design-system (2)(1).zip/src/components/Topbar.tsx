import { useEffect, useState } from "react";
import { Button } from "./ui";
import {
  IconSearch,
  IconBell,
  IconX,
  IconGrid,
  IconArrow,
  LogoColor,
} from "./Icons";
import { NAV } from "../data";

/* ===== Command palette ===== */
export function CommandPalette({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  useEffect(() => {
    if (open) {
      setQ("");
      setSel(0);
    }
  }, [open]);

  const results = NAV.filter((n) => n.label.toLowerCase().includes(q.toLowerCase()));

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSel((s) => Math.min(results.length - 1, s + 1));
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setSel((s) => Math.max(0, s - 1));
      }
      if (e.key === "Enter" && results[sel]) {
        location.hash = results[sel].id;
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, q, sel, results, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-start justify-center px-4 pt-[14vh]"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="el-4 relative w-full max-w-lg overflow-hidden rounded-3xl border border-line/70 bg-gradient-to-b from-card to-surface"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-line/60 px-5 py-4">
          <IconSearch size={18} className="text-teal" />
          <input
            autoFocus
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setSel(0);
            }}
            placeholder="Jump to a section…"
            className="flex-1 bg-transparent text-[15px] text-ink outline-none placeholder:text-dim"
          />
          <kbd className="mono el-press rounded-lg border border-line bg-bg2 px-2 py-1 text-[10px] text-dim">
            ESC
          </kbd>
        </div>
        <div className="max-h-[300px] overflow-auto p-2">
          {results.length === 0 && (
            <p className="px-3 py-6 text-center text-[13px] text-dim">No sections found</p>
          )}
          {results.map((r, i) => (
            <a
              key={r.id}
              href={`#${r.id}`}
              onClick={onClose}
              onMouseEnter={() => setSel(i)}
              className={`flex items-center justify-between rounded-2xl px-4 py-3 text-[14px] transition-colors ${
                i === sel ? "el-1 bg-teal/12 text-teal" : "text-dim"
              }`}
            >
              <span className="font-semibold">{r.label}</span>
              <IconArrow size={15} />
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ===== Scroll progress + intersection observer ===== */
export function useScrollSpy(active: string, setActive: (s: string) => void) {
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      const pct = max > 0 ? (h.scrollTop / max) * 100 : 0;
      (window as unknown as { __progress?: number }).__progress = pct;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    const io = new IntersectionObserver(
      (es) => {
        const vis = es
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (vis[0]) setActive(vis[0].target.id);
      },
      { rootMargin: "-18% 0px -68% 0px" },
    );
    NAV.forEach((n) => {
      const el = document.getElementById(n.id);
      if (el) io.observe(el);
    });
    return () => {
      window.removeEventListener("scroll", onScroll);
      io.disconnect();
    };
  }, [setActive, active]);
}

function useScrollProgress(): number {
  const [p, setP] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      setP(max > 0 ? (h.scrollTop / max) * 100 : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return p;
}

/* ===== Topbar ===== */
export function Topbar({
  active,
  setActive,
}: {
  active: string;
  setActive: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [palette, setPalette] = useState(false);
  const progress = useScrollProgress();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPalette((p) => !p);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <CommandPalette open={palette} onClose={() => setPalette(false)} />

      {/* scroll progress */}
      <div className="fixed inset-x-0 top-0 z-[60] h-[2px] bg-transparent">
        <div
          className="h-full bg-gradient-to-r from-teal via-wait to-pink shadow-[0_0_12px_rgba(46,230,200,.8)] transition-[width] duration-150"
          style={{ width: `${progress}%` }}
        />
      </div>

      <header className="sticky top-0 z-50 px-3 pt-3 sm:px-5 sm:pt-4">
        <div className="el-3 glass mx-auto flex max-w-[1320px] items-center gap-3 rounded-[26px] border border-line/70 px-3 py-2 sm:px-4">
          {/* brand */}
          <a href="#top" className="flex shrink-0 items-center gap-2.5 pl-1">
            <LogoColor size={36} detail={false} />
            <div className="leading-none">
              <p className="font-display text-[14px] font-bold tracking-tight text-ink">
                SIGNAL<span className="text-teal">ARENA</span>
              </p>
              <p className="mono mt-0.5 text-[8px] uppercase tracking-[0.26em] text-dim">
                design system
              </p>
            </div>
          </a>

          {/* center floating nav */}
          <nav className="el-press mx-auto hidden items-center gap-0.5 rounded-full bg-bg2/70 p-1 xl:flex">
            {NAV.map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                onClick={() => setActive(n.id)}
                className={`font-display relative rounded-full px-3 py-1.5 text-[12px] font-semibold transition-colors duration-300 ${
                  active === n.id ? "text-teal" : "text-dim hover:text-ink"
                }`}
              >
                {n.label}
              </a>
            ))}
          </nav>

          {/* right cluster */}
          <div className="ml-auto flex items-center gap-2 lg:ml-0">
            <button
              onClick={() => setPalette(true)}
              className="el-press hidden items-center gap-2 rounded-full border border-line/70 bg-bg2/70 py-2 pl-3.5 pr-2 text-[12px] text-dim transition-colors hover:text-ink md:flex"
            >
              <IconSearch size={14} />
              <span>Search</span>
              <kbd className="mono flex items-center gap-0.5 rounded-md border border-line bg-card px-1.5 py-0.5 text-[10px] text-dim">
                ⌘K
              </kbd>
            </button>

            <button
              onClick={() => setPalette(true)}
              className="el-1 flex h-9 w-9 items-center justify-center rounded-full border border-line/70 bg-gradient-to-b from-card to-surface text-dim md:hidden"
              aria-label="Search"
            >
              <IconSearch size={15} />
            </button>

            <button
              className="el-1 relative hidden h-9 w-9 items-center justify-center rounded-full border border-line/70 bg-gradient-to-b from-card to-surface text-dim transition-colors hover:text-teal sm:flex"
              aria-label="Notifications"
            >
              <IconBell size={15} />
              <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-pink shadow-[0_0_7px_rgba(255,77,148,.9)]" />
            </button>

            <div className="el-1 hidden items-center gap-1.5 rounded-full border border-teal/30 bg-teal/10 px-3 py-1.5 text-[11px] font-semibold text-teal xl:flex">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-teal shadow-[0_0_8px_rgba(46,230,200,.9)]" />
              Tokens synced
            </div>

            <div className="hidden sm:block">
              <Button size="sm" iconRight={<IconArrow size={14} />}>
                Figma kit
              </Button>
            </div>

            <button
              onClick={() => setOpen((o) => !o)}
              className="el-1 flex h-9 w-9 items-center justify-center rounded-xl border border-line bg-gradient-to-b from-card to-surface text-dim xl:hidden"
              aria-label="Menu"
            >
              {open ? <IconX size={16} /> : <IconGrid size={16} />}
            </button>
          </div>
        </div>

        {/* mobile sheet */}
        {open && (
          <div className="el-3 glass mx-auto mt-2 grid max-w-[1320px] grid-cols-2 gap-1 rounded-3xl border border-line/70 p-2 xl:hidden">
            {NAV.map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                onClick={() => {
                  setActive(n.id);
                  setOpen(false);
                }}
                className={`flex items-center gap-2 rounded-2xl px-4 py-3 text-[13px] font-semibold transition-colors ${
                  active === n.id ? "text-teal" : "text-dim hover:bg-white/5"
                }`}
              >
                {active === n.id && (
                  <span className="h-1.5 w-1.5 rounded-full bg-teal shadow-[0_0_8px_rgba(46,230,200,.9)]" />
                )}
                {n.label}
              </a>
            ))}
            <div className="col-span-2 p-2">
              <Button full size="sm">
                Download Figma kit
              </Button>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
