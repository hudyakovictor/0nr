/* ================== Catalog data ================== */

export const NAV = [
  { id: "foundations", label: "Foundations" },
  { id: "color",       label: "Color" },
  { id: "type",        label: "Type" },
  { id: "logo",        label: "Logo" },
  { id: "elevation",   label: "Elevation" },
  { id: "icons",       label: "Icons" },
  { id: "index",       label: "Library" },
  { id: "lessons",     label: "Curriculum" },
  { id: "skill",       label: "Skill cards" },
  { id: "motion-2026", label: "Motion 2026" },
  { id: "components",  label: "Components" },
  { id: "motion",      label: "Motion" },
  { id: "patterns",    label: "Patterns" },
  { id: "pages",       label: "Pages" },
  { id: "screens",     label: "Screens" },
  { id: "audit",       label: "Audit" },
  { id: "brand",       label: "Brand" },
  { id: "changelog",   label: "Changelog" },
  { id: "theming",     label: "Theming" },
  { id: "playground",  label: "Playground" },
  { id: "handoff",     label: "Handoff" },
  { id: "roadmap",     label: "Roadmap" },
  { id: "sitemap",     label: "Sitemap" },
] as const;

export const FOUNDATIONS = [
  { t: "Grid",     s: "4pt base · 8pt rhythm",   d: "Spacing 4→96 with safe-area insets on all edges." },
  { t: "Radius",   s: "12 / 16 / 24 / 32 / 46",  d: "Nested-radius rule: child = parent − padding." },
  { t: "Motion",   s: "180 – 420 ms",            d: "Expo-out easing, 1px press translate, no bounce." },
  { t: "Density",  s: "Comfortable",             d: "44pt minimum targets, 8pt minimum separation." },
];

export const AUDIT_ROWS = [
  ["Visual hierarchy",        96],
  ["Color & contrast",        94],
  ["Depth & elevation",       97],
  ["Typography",              92],
  ["Motion safety",           93],
  ["Ergonomics (thumb zone)", 91],
  ["Token consistency",       98],
  ["Logo & brand",            95],
] as const;

export const LESSONS = [
  { key: "beginner",     title: "Beginner",  items: [
    { id: "wallet",     title: "Crypto wallets 101",     mins: 9,  done: true },
    { id: "keys",       title: "Public & private keys",  mins: 7,  done: true },
    { id: "blockchain", title: "How blockchains work",   mins: 12, done: true },
    { id: "consensus",  title: "Consensus mechanisms",   mins: 14, done: true },
    { id: "tokens",     title: "Tokens vs coins",        mins: 8,  done: true },
    { id: "gas",        title: "Gas & transaction fees", mins: 11, done: true },
    { id: "explorer",   title: "Reading the block explorer", mins: 10, done: false, current: true },
    { id: "scams",      title: "Avoiding common scams",  mins: 9,  done: false },
  ]},
  { key: "intermediate", title: "Intermediate", items: [
    { id: "defi",     title: "DeFi primitives",       mins: 18, done: false },
    { id: "lp",       title: "Liquidity pools",       mins: 14, done: false },
    { id: "staking",  title: "Staking & slashing",    mins: 12, done: false },
    { id: "nft",      title: "NFT fundamentals",      mins: 11, done: false },
  ]},
  { key: "advanced",     title: "Advanced", items: [
    { id: "amm",      title: "AMM math",              mins: 22, done: false },
    { id: "mev",      title: "MEV & protection",      mins: 19, done: false },
    { id: "rollup",   title: "Rollups vs sidechains", mins: 17, done: false },
  ]},
];

export const QUIZ_QUESTIONS = [
  {
    topic: "CONSENSUS",
    q: "What secures a Proof-of-Stake network?",
    explain: "Validators lock capital as collateral — dishonest behaviour gets slashed.",
    options: [
      { k: "A", t: "Mining hardware power",        correct: false },
      { k: "B", t: "Validators staking capital",   correct: true },
      { k: "C", t: "Centralized approval",         correct: false },
      { k: "D", t: "Random block lottery",         correct: false },
    ],
  },
  {
    topic: "WALLETS",
    q: "What does a private key actually prove?",
    explain: "It proves you control the address — without revealing the key itself (signatures).",
    options: [
      { k: "A", t: "Your bank balance",            correct: false },
      { k: "B", t: "Ownership of an address",     correct: true },
      { k: "C", t: "Identity to a CEX",            correct: false },
      { k: "D", t: "Transaction amount",           correct: false },
    ],
  },
  {
    topic: "DEFI",
    q: "Where do AMM prices come from?",
    explain: "The constant product x·y=k. Prices slip as trades change the pool ratio.",
    options: [
      { k: "A", t: "An external order book",       correct: false },
      { k: "B", t: "The constant product formula", correct: true },
      { k: "C", t: "The most recent trade",        correct: false },
      { k: "D", t: "An oracle price feed",         correct: false },
    ],
  },
];

export const COINS_SEED = [
  { s: "BTC",  n: "Bitcoin",     p: 68412.30, c:  2.41 },
  { s: "ETH",  n: "Ethereum",    p:  3884.10, c:  1.12 },
  { s: "SOL",  n: "Solana",      p:   182.40, c: -3.08 },
  { s: "AVAX", n: "Avalanche",   p:    42.71, c:  5.66 },
  { s: "DOT",  n: "Polkadot",    p:     8.94, c: -0.74 },
  { s: "ARB",  n: "Arbitrum",    p:     1.18, c:  0.31 },
  { s: "LINK", n: "Chainlink",   p:    18.62, c:  4.05 },
];

export const ASSETS = [
  { s: "BTC", n: "0.0842",  v: "$5,760.12",  c: "+2.4%",  up: true },
  { s: "ETH", n: "1.2400",  v: "$4,816.16",  c: "+1.1%",  up: true },
  { s: "SOL", n: "12.40",   v: "$2,261.76",  c: "-3.1%",  up: false },
  { s: "ARB", n: "845.30",  v: "$1,002.45",  c: "+0.3%",  up: true },
];

export const ACHIEVEMENTS = [
  { I: "shield",  name: "First Wallet",   unlocked: true  },
  { I: "cube",    name: "Block by Block", unlocked: true  },
  { I: "wave",    name: "DeFi Curious",   unlocked: true  },
  { I: "gift",    name: "Reward Hunter",  unlocked: true  },
  { I: "bolt",    name: "Speed Reader",   unlocked: true  },
  { I: "lock",    name: "Vault Builder",  unlocked: false },
  { I: "chart",   name: "Market Watcher", unlocked: false },
  { I: "trophy",  name: "Top 10%",        unlocked: false },
];

export const SAMPLE_TXN = [
  { s: "Receive", who: "0x8f2a…c41d",    v: "+0.0084 ETH",  t: "12 min ago", tone: "up"   as const },
  { s: "Swap",    who: "ETH → USDC",      v: "-0.052 ETH",   t: "2 h ago",    tone: "dim"  as const },
  { s: "Stake",   who: "Validator #3241", v: "+12.4 ATOM",   t: "1 d ago",    tone: "lime" as const },
  { s: "Send",    who: "0x3a1f…009b",     v: "-50 USDC",     t: "3 d ago",    tone: "down" as const },
];

export const PORTFOLIO_PATH = [56, 49, 53, 32, 39, 20, 27, 11, 18];

export const MARQUEE = [
  "14 semantic tokens",
  "5-tier elevation",
  "1 glyph · 3 versions",
  "26 line icons",
  "52 components",
  "WCAG AAA text",
  "Reduced-motion safe",
  "Dark-first",
  "Haptic press states",
  "Tabular numerics",
] as const;
